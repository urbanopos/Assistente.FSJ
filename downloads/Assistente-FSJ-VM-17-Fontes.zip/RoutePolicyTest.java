package br.com.fazendasaojose.reservavm;
import java.util.*;import java.io.*;
public class RoutePolicyTest{
 static void require(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  List<String> calls=new ArrayList<>(),notices=new ArrayList<>();
  String result=RoutePolicy.choose(RoutePolicy.ALLOWED[1],origin->{calls.add(origin);return true;},(o,a)->notices.add(o+":"+a));require(result.equals(RoutePolicy.PUBLIC));require(calls.size()==1);
  calls.clear();notices.clear();result=RoutePolicy.choose(RoutePolicy.ALLOWED[1],origin->{calls.add(origin);return origin.equals(RoutePolicy.ALLOWED[1]);},(o,a)->notices.add(o+":"+a));require(calls.size()==6);for(int i=0;i<5;i++){require(calls.get(i).equals(RoutePolicy.PUBLIC));require(notices.get(i).endsWith(":"+(i+1)));}require(result.equals(RoutePolicy.ALLOWED[1]));
  calls.clear();result=RoutePolicy.choose("https://malicioso.invalid/",origin->{calls.add(origin);return origin.equals(RoutePolicy.ALLOWED[3]);});require(calls.size()==8);require(!calls.contains("https://malicioso.invalid/"));
  calls.clear();try{RoutePolicy.choose(null,origin->{calls.add(origin);return false;});throw new AssertionError();}catch(IOException expected){require(calls.size()==8);require(expected.getMessage().contains("Wi-Fi"));}
  calls.clear();Thread.currentThread().interrupt();try{RoutePolicy.choose(null,origin->{calls.add(origin);return false;});throw new AssertionError();}catch(InterruptedIOException expected){require(calls.isEmpty());}finally{Thread.interrupted();}
  System.out.println("PASS: publico preferencial, cinco tentativas com avisos, alternativa local, destinos limitados, indisponibilidade e cancelamento.");
 }
}
