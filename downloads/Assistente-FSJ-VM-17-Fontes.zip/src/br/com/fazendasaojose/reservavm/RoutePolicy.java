package br.com.fazendasaojose.reservavm;
import java.io.IOException;import java.io.InterruptedIOException;import java.util.LinkedHashSet;import java.util.Arrays;
final class RoutePolicy {
 static final String PUBLIC="https://168.196.84.147/";
 static final String[] ALLOWED={PUBLIC,"https://192.168.1.114:8443/","https://192.168.1.100:8443/","https://192.168.77.2:8443/"};
 interface Probe{boolean reachable(String origin);}
 interface Progress{void trying(String origin,int attempt);}
 static String choose(String saved,Probe probe)throws IOException{return choose(saved,probe,(origin,attempt)->{});}
 static String choose(String saved,Probe probe,Progress progress)throws IOException{
  for(int attempt=1;attempt<=5;attempt++){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Conexão cancelada.");progress.trying(PUBLIC,attempt);if(probe.reachable(PUBLIC))return PUBLIC;}
  LinkedHashSet<String> local=new LinkedHashSet<>();if(!PUBLIC.equals(saved)&&Arrays.asList(ALLOWED).contains(saved))local.add(saved);
  for(String origin:ALLOWED)if(!PUBLIC.equals(origin))local.add(origin);
  for(String origin:local){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Conexão cancelada.");progress.trying(origin,1);if(probe.reachable(origin))return origin;}
  throw new IOException("A rede pública não respondeu em 5 tentativas e a VM não foi encontrada pela rede local. Escolha outro Wi-Fi ou tente novamente. Fora da fazenda, o servidor precisa estar acessível pela internet.");
 }
}
