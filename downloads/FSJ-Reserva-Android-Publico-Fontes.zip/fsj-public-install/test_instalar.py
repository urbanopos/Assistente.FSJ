import importlib.util,unittest,tempfile,ssl,hashlib,json,sys,subprocess
from pathlib import Path
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('installer',Path(__file__).with_name('instalar.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class InstallTest(unittest.TestCase):
 def test_preserves_other_screens(self):
  original='<header>novo</header>'+m.CARD+'<section id="tasks">tarefas novas</section>'
  self.assertEqual(m.change_card(original),original)
  with self.assertRaises(RuntimeError):m.change_card('<header>outra interface</header>')
 def check_install(self,fail=False):
  with tempfile.TemporaryDirectory() as folder:
   target=Path(folder)/'fsj';tls=target/'dados/tls';tls.mkdir(parents=True)
   subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-days','1','-keyout',str(tls/'fsj-ca.key'),'-out',str(tls/'fsj-ca.crt'),'-subj','/CN=Test','-addext','basicConstraints=critical,CA:TRUE'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
   ca_hash=hashlib.sha256(ssl.PEM_cert_to_DER_cert((tls/'fsj-ca.crt').read_text())).hexdigest()
   (target/'static').mkdir();index='<header>latest</header>'+m.CARD+'<section id="tasks">keep</section>'
   (target/'static/index.html').write_text(index);(target/'version.json').write_text('{"release":9,"android_version":9}')
   (target/'dados/preserve').write_text('keep');(tls/'servidor.crt').write_text('old-cert');(tls/'servidor.key').write_text('old-key')
   real=m.run
   def command(*args):return b'' if args[0]=='systemctl' else real(*args)
   state=[0]
   def health(_):
    state[0]+=1
    return {'busy':False,'android_version':9 if fail or state[0]==1 else 10}
   with patch.object(m,'CA_HASH',ca_hash),patch.object(m,'run',command),patch.object(m,'health',health),patch.object(m.time,'sleep'),patch.object(sys,'argv',['instalar.py',str(target)]):
    if fail:
     with self.assertRaises(RuntimeError):m.main()
     self.assertEqual((tls/'servidor.crt').read_text(),'old-cert');self.assertEqual(json.loads((target/'version.json').read_text())['android_version'],9)
    else:
     m.main();real('openssl','verify','-CAfile',tls/'fsj-ca.crt','-verify_ip',m.PUBLIC,tls/'servidor.crt')
     self.assertEqual(json.loads((target/'version.json').read_text())['release'],9)
    self.assertEqual((target/'dados/preserve').read_text(),'keep');self.assertEqual((target/'static/index.html').read_text(),index)
 def test_install_certificate_and_preserve(self):self.check_install()
 def test_health_failure_rolls_back(self):self.check_install(True)

if __name__=='__main__':unittest.main()
