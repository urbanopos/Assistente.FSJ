"""Authenticated in-memory signaling. Media flows directly between invited LAN peers."""
import secrets,time,threading
from collections import deque

class CallError(Exception):
 def __init__(self,message,status=400):super().__init__(message);self.status=status

class CallHub:
 def __init__(self,account):self.account=account;self.rooms={};self.lock=threading.RLock()
 def _prune(self):
  now=time.time()
  for ident,room in list(self.rooms.items()):
   for uid,peer in list(room['peers'].items()):
    if peer['seen']<now-45 or not self.account(uid):room['peers'].pop(uid,None)
   if room['expires']<now or not self.account(room['owner']) or (room['started'] and room['owner'] not in room['peers']):self.rooms.pop(ident,None)
 def _room(self,user,ident):
  self._prune();room=self.rooms.get(ident)
  if not room or user['id'] not in room['invited']:raise CallError('Chamada encerrada ou convite indisponível.',410)
  return room
 def _peer(self,user,room,nonce):
  peer=room['peers'].get(user['id'])
  if not peer or not secrets.compare_digest(peer['nonce'],str(nonce)):raise CallError('Entre novamente na chamada.',409)
  peer['seen']=time.time();return peer
 def _summary(self,room,user):
  return {'id':room['id'],'title':room['title'],'owner':room['owner'],'recording':room['recording'],'expires':room['expires'],'members':[{'id':uid,'name':a['display_name'] or a['name'],'present':uid in room['peers']} for uid in room['invited'] if (a:=self.account(uid))],'can_end':user['id']==room['owner']}
 def list(self,user):
  with self.lock:
   self._prune();return {'calls':[self._summary(r,user) for r in self.rooms.values() if user['id'] in r['invited']]}
 def revoke(self,uid):
  with self.lock:
   for ident,room in list(self.rooms.items()):
    room['peers'].pop(uid,None)
    if room['owner']==uid:self.rooms.pop(ident,None)
 def post(self,user,action,data):
  with self.lock:
   self._prune()
   if action=='create':
    if user['role']!='owner':raise CallError('Apenas o Proprietário pode iniciar convites.',403)
    ids=data.get('participants');title=str(data.get('title','Conversa FSJ')).strip()
    if not isinstance(ids,list) or not 1<=len(ids)<=3 or len(set(ids))!=len(ids) or user['id'] in ids or not 1<=len(title)<=100:raise CallError('Convide de um a três participantes e informe um título.')
    if any(not isinstance(uid,str) or not self.account(uid) for uid in ids):raise CallError('Selecione apenas contas ativas.')
    if any(r['owner']==user['id'] for r in self.rooms.values()):raise CallError('Encerre a chamada anterior antes de criar outra.',409)
    ident=secrets.token_hex(16);room={'id':ident,'title':title,'owner':user['id'],'invited':[user['id'],*ids],'peers':{},'events':deque(maxlen=512),'seq':0,'recording':False,'started':False,'expires':time.time()+5400};self.rooms[ident]=room
    return {'call':self._summary(room,user)}
   room=self._room(user,str(data.get('room','')))
   if action=='end':
    if user['id']!=room['owner']:raise CallError('Apenas o Proprietário encerra a chamada de todos.',403)
    self.rooms.pop(room['id'],None);return {'ok':True}
   if action=='join':
    if user['id'] in room['peers']:raise CallError('Sua conta já entrou nesta chamada. Saia no outro aparelho ou aguarde 45 segundos.',409)
    nonce=secrets.token_urlsafe(24);room['peers'][user['id']]={'nonce':nonce,'seen':time.time(),'sent':deque()}
    if user['id']==room['owner']:room['started']=True
    return {'nonce':nonce,'cursor':room['seq'],'call':self._summary(room,user)}
   peer=self._peer(user,room,data.get('nonce',''))
   if action=='leave':
    room['peers'].pop(user['id'],None)
    if user['id']==room['owner']:self.rooms.pop(room['id'],None)
    return {'ok':True}
   if action=='poll':
    after=data.get('after',0)
    if not isinstance(after,int) or after<0 or after>room['seq']:raise CallError('Cursor inválido.')
    if room['events'] and after<room['events'][0]['seq']-1:raise CallError('Reconecte-se à chamada para recuperar a conexão.',409)
    return {'call':self._summary(room,user),'cursor':room['seq'],'events':[e for e in room['events'] if e['seq']>after and e['to']==user['id']]}
   if action=='record':
    if user['id']!=room['owner'] or not isinstance(data.get('recording'),bool):raise CallError('Somente o Proprietário pode gravar.',403)
    room['recording']=data['recording'];return {'ok':True}
   if action!='signal':raise CallError('Ação inválida.')
   target=data.get('to');signal=data.get('signal')
   if target==user['id'] or target not in room['peers'] or target not in room['invited'] or not self.account(target):raise CallError('Participante fora da chamada.',409)
   if not isinstance(signal,dict) or signal.get('type') not in ('offer','answer','candidate'):raise CallError('Sinal inválido.')
   if signal['type'] in ('offer','answer'):
    if not isinstance(signal.get('sdp'),str) or not 1<=len(signal['sdp'])<=24576:raise CallError('Descrição de conexão inválida.')
    clean={'type':signal['type'],'sdp':signal['sdp']}
   else:
    candidate=signal.get('candidate')
    if not isinstance(candidate,dict) or not isinstance(candidate.get('candidate'),str) or len(candidate['candidate'])>4096 or candidate.get('sdpMid') is not None and not isinstance(candidate['sdpMid'],str) or candidate.get('sdpMLineIndex') is not None and (not isinstance(candidate['sdpMLineIndex'],int) or not 0<=candidate['sdpMLineIndex']<=10):raise CallError('Candidato de conexão inválido.')
    clean={'type':'candidate','candidate':{k:candidate.get(k) for k in ('candidate','sdpMid','sdpMLineIndex','usernameFragment')}}
   now=time.time()
   while peer['sent'] and peer['sent'][0]<now-60:peer['sent'].popleft()
   if len(peer['sent'])>=120:raise CallError('Muitas atualizações. Aguarde e reconecte.',429)
   peer['sent'].append(now);room['seq']+=1;room['events'].append({'seq':room['seq'],'from':user['id'],'to':target,'signal':clean})
   return {'ok':True}
