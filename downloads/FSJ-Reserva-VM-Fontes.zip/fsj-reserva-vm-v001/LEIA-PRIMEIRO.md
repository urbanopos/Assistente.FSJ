# Reserva — Release 2 / Android 7

Telas sem rolagem, navegação Anterior/Próximo, logotipo original proporcional, cabeçalho RESERVA sem R, seleção de vídeo e pessoas lado a lado, acesso permanente a Tarefas e Vídeos. Vídeo institucional e biblioteca usam um só player.

O Android 7 oferece Salvar acesso neste aparelho. Após um login válido, o usuário e a senha são cifrados com AES-GCM e chave do Android Keystore, em armazenamento privado sem backup do app. Nada é salvo em texto simples ou enviado ao GitHub. A opção pode ser desmarcada para esquecer. Sair continua encerrando sessão e aplicativo; na próxima entrada o formulário pode ser preenchido automaticamente, mas o servidor sempre verifica a senha e o estado da conta. Conferência no aparelho ainda necessária.

Espelhamento de leitura principal → VM, a cada 60 segundos. Inclui pessoas, grupos, tarefas, responsáveis, respostas e execuções. O Android consulta apenas a VM. Sem conexão, a última cópia local é preservada, com data de sincronização e aviso de falha. Não escreve alterações de tarefas no principal nesta versão.

O arquivo privado FSJ-Conexao-Registros.json é entregue separadamente ao Proprietário. Copiar para dados/sync.json (modo 600) ou enviar pelo formulário proprietário Tarefas → Conectar registros do principal. Não incluir esse arquivo em releases, GitHub, APK ou no acesso de participantes.

Participantes: o diretório mostra as pessoas espelhadas e indica as que ainda não têm acesso local. Em Autorizações e contas, vincular explicitamente uma conta à pessoa do principal e autorizar o acesso. Não há vinculação automática por coincidência de nomes. Somente contas ativas podem ser convidadas. Um participante vê apenas suas tarefas. Bloquear/excluir conta ou desativar a pessoa vinculada impede acesso. Até três convidados mais o Proprietário por chamada.

Publicação pelo canal assinado de atualização instalado na VM. A alteração do servidor exige um reinício e pode pedir login uma vez. Contas, vídeos, certificados e arquivo de conexão são mantidos. Testes: escopo dos registros, bloqueio por cadastro inativo, conservação da cópia após falha, consulta real de 7 pessoas e 39 tarefas, geometria de telas a 568/640/780/844px, formulário de senha salva e compilação/assinatura do APK. Mídia entre aparelhos e Android Keystore real ainda dependem de verificação nos aparelhos.
