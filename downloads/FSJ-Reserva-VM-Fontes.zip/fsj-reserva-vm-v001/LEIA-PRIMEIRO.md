# Reserva — Release 2 / Android 7

Telas sem rolagem, navegação Anterior/Próximo, logotipo original proporcional, cabeçalho RESERVA sem R, seleção de vídeo e pessoas lado a lado, acesso permanente a Tarefas e Vídeos. Vídeo institucional e biblioteca usam um só player.

O Android 7 oferece Salvar acesso neste aparelho. Após um login válido, o usuário e a senha são cifrados com AES-GCM e chave do Android Keystore, em armazenamento privado sem backup do app. Nada é salvo em texto simples ou enviado ao GitHub. A opção pode ser desmarcada para esquecer. Sair continua encerrando sessão e aplicativo; na próxima entrada o formulário pode ser preenchido automaticamente, mas o servidor sempre verifica a senha e o estado da conta. Conferência no aparelho ainda necessária.

Espelhamento de leitura principal → VM, a cada 60 segundos. Inclui pessoas, grupos, tarefas, responsáveis, respostas e execuções. O Android consulta apenas a VM. Sem conexão, a última cópia local é preservada, com data de sincronização e aviso de falha. Não escreve alterações de tarefas no principal nesta versão.

O arquivo privado FSJ-Conexao-Registros.json é entregue separadamente ao Proprietário. Copiar para dados/sync.json (modo 600) ou enviar pelo formulário proprietário Tarefas → Conectar registros do principal. Não incluir esse arquivo em releases, GitHub, APK ou no acesso de participantes.

Participantes: o diretório mostra as pessoas espelhadas e indica as que ainda não têm acesso local. Em Autorizações e contas, vincular explicitamente uma conta à pessoa do principal e autorizar o acesso. Não há vinculação automática por coincidência de nomes. Somente contas ativas podem ser convidadas. Um participante vê apenas suas tarefas. Bloquear/excluir conta ou desativar a pessoa vinculada impede acesso. Até três convidados mais o Proprietário por chamada.

Publicação pelo canal assinado de atualização instalado na VM. A alteração do servidor exige um reinício e pode pedir login uma vez. Contas, vídeos, certificados e arquivo de conexão são mantidos. Testes: escopo dos registros, bloqueio por cadastro inativo, conservação da cópia após falha, consulta real de 7 pessoas e 39 tarefas, geometria de telas a 568/640/780/844px, formulário de senha salva e compilação/assinatura do APK. Mídia entre aparelhos e Android Keystore real ainda dependem de verificação nos aparelhos.


## Release 3 / Android 7

Listas de vídeos e participantes preservam seleção durante consultas de fundo. Atualizações de opções aguardam o fechamento da lista. Pessoas do cadastro principal aparecem uma vez por identificador; contas locais sem vínculo permanecem em Contas para vinculação explícita. Nenhum registro é apagado. Interface atualizada sem reiniciar o servidor; APK permanece versão 7.


## Release 4 / Android 7

Preparação de chamadas salva por usuário neste aparelho, com título e convidados. Atualizar participantes preserva a seleção; avisos de chamada aparecem no rodapé visível. A edição do título não é interrompida pelo redimensionamento do teclado. Ao entrar, a navegação exibe o quadro da chamada. Somente contas ativas explicitamente vinculadas podem ser convidadas quando existe cadastro principal. O teste usa câmera simulada; mídia entre aparelhos requer verificação na rede local.


## Release 5 / Android 7

Todos os cadastros ativos do principal entram automaticamente na lista de convidados, uma vez por ID da pessoa. Podem receber convites antes de criar conta local. Aceitar o convite exige entrar com conta autorizada vinculada à pessoa correta; não há associação automática por nome nem importação de senhas. Pessoas inativas e contas vinculadas bloqueadas não podem participar. A atualização altera o servidor e reinicia o serviço quando não há chamada ou gravação; pode ser necessário entrar novamente. Inclui as correções de preparação, título salvo e avisos visíveis da release 4.


## Release 6 / Android 8

O principal oferece Vídeos e chamadas na tela inicial e na navegação. No Android, o link fsjreservavm://videos abre o aplicativo exclusivo da VM; se indisponível, oferece o APK8. No desktop, abre HTTPS da VM. O APK8 registra somente essa rota e continua aceitando rede exclusivamente do endereço fixo da VM, com a CA embarcada. A chave de assinatura é preservada. Um aplicativo Android comum exige confirmação para instalar a atualização nativa; as atualizações da interface da VM continuam automáticas. Abertura do link no aparelho e permissões de câmera precisam de conferência real.


## Release 7 / Android 8

Selecionar um vídeo da biblioteca inicia sua reprodução no mesmo player do institucional. Ao terminar, limpa a seleção e restaura o institucional, iniciando sua reprodução se o aparelho permitir. Se não existir institucional cadastrado, volta ao quadro vazio correspondente. O término do próprio institucional não entra em repetição. Atualização de interface sem reiniciar servidor nem alterar arquivos de vídeo.


## Release 8 / Android 9

- Um botão discreto amplia o player e outro toque restaura a tela. O APK9 implementa tela cheia nativa, com saída pelo botão e Voltar. A imagem conserva a proporção original.
- A lista agrupa títulos iguais após normalização de espaços e caixa. Mostra o envio mais recente, sem excluir arquivos nem registros.
- Seleções não são reconstruídas a cada consulta. Uma barra sempre visível permite entrar e finalizar a chamada; uma preparação pendente pode ser retomada. Tipo de chamada: Vídeo e voz ou Somente voz (não solicita câmera).
- Exibição em grupo usa convites autenticados e o mesmo player. Selecione vídeo e até três pessoas, toque em Exibir vídeo aos selecionados; os convidados entram em Assistir com o grupo. Aguarde todos entrarem e dê play. O Proprietário controla início, pausa e avanço. Cada cliente lê o arquivo diretamente da VM e acompanha a posição publicada por ela. Há tolerância a atrasos da rede, sem garantia de sincronização quadro a quadro. Ao terminar, todos voltam ao institucional.
- Um convite de exibição concede acesso temporário somente ao vídeo selecionado. Outros usuários não acessam a sessão ou mídia; participantes não controlam o grupo e não recebem download. Ao finalizar, expirar ou bloquear acesso, a concessão termina. Sessões são temporárias e encerram se o Proprietário parar de responder por 45 segundos.
- Os testes de navegador usam três sessões e mídia sintética: seleção, títulos únicos, tela cheia, controle e retorno da exibição em grupo, início/finalização de voz e vídeo, autorização e SDP. O ambiente de testes não gerou candidatos ICE; mídia WebRTC entre aparelhos ainda exige teste na rede real. O suporte nativo a tela cheia foi compilado e a assinatura conferida, mas requer conferência no Android real.
- Testes: python3 -m unittest discover -p 'test_*.py'. Navegador: instale playwright/Chromium e ffmpeg e execute node test_browser.cjs. FSJ_SIGNAL_ONLY=1 testa SDP quando o ambiente não disponibiliza ICE. Não confunda esse modo com teste de mídia entre aparelhos.
- A VM aplica o pacote assinado automaticamente, com backup e reinício do servidor quando estiver livre. Android9 é oferecido pelo aplicativo; o sistema Android exige confirmação de instalação. Não são necessários ZIPs, comandos ou reinstalação de certificados.


## Release 9 / Android 9 / iPhone e iPad pela web

A página principal de instalação oferece Android (APK9) e iPhone/iPad (aplicativo web adicionado à Tela de Início pelo Safari). A VM fornece manifesto standalone, ícone PNG da marca e instruções locais em /instalar/ios. Os dados, sessões, tarefas, biblioteca e chamadas continuam servidos pela VM, sem novo backend externo. Nenhum service worker armazena APIs ou vídeos; as atualizações continuam vindo do servidor.

Não existe IPA assinado nem distribuição App Store neste pacote. Distribuição nativa de iOS exige Xcode e assinatura/provisionamento Apple. A versão web possui diferenças do Android: instalação pelo Safari, confiança manual na CA local na configuração inicial, Sair encerra sessão mas não força o iOS a voltar à Tela de Início, e senhas são gerenciadas pelo preenchimento automático do sistema em vez do Android Keystore. Recursos de gravação, reprodução e câmera dependem da versão do iOS; não foi realizado teste em iPhone real. Portanto, não se afirma paridade nativa completa.

Gravação negocia WebM ou MP4 conforme MediaRecorder.isTypeSupported e preserva o tipo correto no envio. O player usa tela cheia web e alternativa webkitEnterFullscreen. Há detecção de aplicativo standalone para ocultar a oferta de instalação depois de adicionado o ícone.

A página pública instalar-reserva.html contém somente instruções, links e a impressão digital do certificado público. downloads/fsj-ca-publico.cer corresponde à CA já embarcada no APK; não contém chave privada nem credenciais. Se a CA da VM for trocada, esse arquivo e os instaladores nativos precisam ser substituídos pelo Proprietário. Não instale certificados divergentes.

Testes verificam manifesto, ícone, rotas públicas de instalação, logout com sessão revogada, detecção standalone e regressões do grupo/chamadas. O teste da interface com identificação iPhone em Chromium não substitui Safari real. O WebKit Linux foi obtido, mas faltam dependências para executá-lo neste ambiente; instalação de perfil e câmera no iOS permanecem pendentes.

Referências oficiais: https://support.apple.com/pt-br/guide/iphone/iphea86e5236/ios ; https://support.apple.com/pt-br/102390 ; https://developer.apple.com/documentation/xcode/distributing-your-app-for-beta-testing-and-releases ; https://webkit.org/blog/11353/mediarecorder-api/ .
