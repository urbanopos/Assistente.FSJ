package br.com.fazendasaojose.reservavm;
import android.content.*;
import android.util.Base64;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
final class DeviceStore {
 private static SecretKey key()throws Exception{java.security.KeyStore s=java.security.KeyStore.getInstance("AndroidKeyStore");s.load(null);String a="fsj-device-calls-v12";if(s.containsAlias(a))return (SecretKey)s.getKey(a,null);KeyGenerator g=KeyGenerator.getInstance("AES","AndroidKeyStore");g.init(new android.security.keystore.KeyGenParameterSpec.Builder(a,3).setBlockModes("GCM").setEncryptionPaddings("NoPadding").build());return g.generateKey();}
 static synchronized void save(Context c,String token)throws Exception{Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());c.getSharedPreferences("device-calls",0).edit().putString("iv",Base64.encodeToString(cipher.getIV(),2)).putString("value",Base64.encodeToString(cipher.doFinal(token.getBytes("UTF-8")),2)).commit();}
 static synchronized String read(Context c){try{SharedPreferences p=c.getSharedPreferences("device-calls",0);String iv=p.getString("iv",null),v=p.getString("value",null);if(iv==null||v==null)return "";Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(iv,2)));return new String(cipher.doFinal(Base64.decode(v,2)),"UTF-8");}catch(Exception e){return "";}}
 static synchronized void clear(Context c){c.getSharedPreferences("device-calls",0).edit().clear().commit();}
}
