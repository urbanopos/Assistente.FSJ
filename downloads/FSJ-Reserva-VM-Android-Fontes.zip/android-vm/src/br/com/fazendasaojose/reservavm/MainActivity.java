package br.com.fazendasaojose.reservavm;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.view.View;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

/** Standalone client: every network request must match the owner's configured VM origin. */
public final class MainActivity extends Activity {
 private WebView web; private LinearLayout layout;
 private static final String ROOT="https://192.168.1.114:8443/";
 private final String root=ROOT; private String pendingDownload; private ValueCallback<Uri[]> fileCallback;
 private volatile boolean checkingUpdate=false; private long lastUpdateCheck=0; private boolean apkPending=false;
 private volatile boolean exiting=false; private volatile HttpURLConnection activeDownload;
 private boolean sslNotice=false; private PermissionRequest mediaRequest;
 private int port(Uri u){return u.getPort()==-1?443:u.getPort();}
 private boolean allowed(String value){try{Uri a=Uri.parse(root),u=Uri.parse(value);return !root.isEmpty()&&"https".equals(u.getScheme())&&a.getHost().equalsIgnoreCase(u.getHost())&&port(a)==port(u)&&u.getUserInfo()==null;}catch(Exception e){return false;}}
 @Override public void onCreate(Bundle state){super.onCreate(state);
  layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setBackgroundColor(Color.rgb(241,245,241));
  web=new WebView(this);layout.addView(web,new LinearLayout.LayoutParams(-1,0,1));setContentView(layout);
  layout.setOnApplyWindowInsetsListener((v,insets)->{if(android.os.Build.VERSION.SDK_INT>=30){android.graphics.Insets i=insets.getInsets(android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.ime());v.setPadding(i.left,i.top,i.right,i.bottom);}else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});
  WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setSupportMultipleWindows(false);s.setSafeBrowsingEnabled(false);s.setMediaPlaybackRequiresUserGesture(false);s.setUserAgentString(s.getUserAgentString()+" FSJReservaVM/7");CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
  web.addJavascriptInterface(new ExitBridge(),"FSJAndroid");
  web.setWebViewClient(new WebViewClient(){
   @Override public void onPageFinished(WebView view,String url){if(allowed(url)&&!exiting)view.evaluateJavascript("(()=>{if(window.__fsjExitBound)return;window.__fsjExitBound=true;document.addEventListener('click',function(e){if(!e.isTrusted||!e.target.closest||!e.target.closest('#logout'))return;e.preventDefault();e.stopImmediatePropagation();try{window.fsjCallsStop&&window.fsjCallsStop();document.querySelectorAll('video,audio').forEach(v=>{v.pause();if(v.srcObject)v.srcObject.getTracks().forEach(t=>t.stop());v.srcObject=null;v.removeAttribute('src');v.load();});}finally{FSJAndroid.exit();}},true);})();(()=>{if(window.__fsjLoginBound)return;window.__fsjLoginBound=true;let pending=null;const form=document.getElementById('loginForm'),box=document.getElementById('rememberLogin'),label=document.getElementById('rememberLoginLabel');if(!form||!box)return;if(label)label.hidden=false;try{const saved=JSON.parse(FSJAndroid.savedLogin());if(saved.name&&saved.password){document.getElementById('name').value=saved.name;document.getElementById('password').value=saved.password;box.checked=true;}}catch{}box.addEventListener('change',()=>{if(!box.checked)FSJAndroid.saveLogin('','',false);});form.addEventListener('submit',()=>{pending={name:document.getElementById('name').value,password:document.getElementById('password').value,remember:box.checked};},true);document.addEventListener('fsj:session',()=>{if(pending){FSJAndroid.saveLogin(pending.name,pending.password,pending.remember);pending=null;}});})()",null);}
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){return !allowed(req.getUrl().toString());}
   @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest req){if(allowed(req.getUrl().toString()))return null;return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",java.util.Collections.emptyMap(),new ByteArrayInputStream("Destino fora da VM bloqueado".getBytes(java.nio.charset.StandardCharsets.UTF_8)));}
   @Override public void onReceivedSslError(WebView view,SslErrorHandler handler,SslError error){handler.cancel();if(!sslNotice){sslNotice=true;message("Certificado não reconhecido ou endereço diferente do certificado. O certificado público da VM já está incluído no aplicativo. Confira a data e a hora do celular; se o erro persistir, avise o Proprietário. A conexão foi bloqueada.");}}
   @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error){if(request.isForMainFrame())message("Não foi possível alcançar a VM. Confira o endereço, a rede e se o servidor está ligado. "+error.getDescription());}
  });
  web.setWebChromeClient(new WebChromeClient(){
   @Override public void onPermissionRequest(PermissionRequest request){runOnUiThread(()->requestMedia(request));}
   @Override public void onPermissionRequestCanceled(PermissionRequest request){runOnUiThread(()->{if(mediaRequest==request)mediaRequest=null;});}

   @Override public boolean onJsConfirm(WebView v,String url,String text,JsResult result){if(!allowed(url)){result.cancel();return true;}new AlertDialog.Builder(MainActivity.this).setMessage(text).setPositiveButton("Confirmar",(d,w)->result.confirm()).setNegativeButton("Cancelar",(d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show();return true;}
   @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> callback,FileChooserParams params){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=callback;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);String[] accepted=params.getAcceptTypes();i.setType(accepted.length==1&&!accepted[0].isEmpty()?accepted[0]:"video/*");try{startActivityForResult(i,700);}catch(Exception e){callback.onReceiveValue(null);fileCallback=null;}return true;}
  });
  web.setDownloadListener((url,agent,disposition,mime,length)->{if(!allowed(url))return;pendingDownload=url;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime==null?"video/mp4":mime);i.putExtra(Intent.EXTRA_TITLE,URLUtil.guessFileName(url,disposition,mime));try{startActivityForResult(i,701);}catch(Exception e){message("Não foi possível abrir o destino do arquivo.");}});
  open();
 }

 private long appVersion(android.content.pm.PackageInfo p){return android.os.Build.VERSION.SDK_INT>=28?p.getLongVersionCode():p.versionCode;}
 private android.content.pm.Signature[] signers(android.content.pm.PackageInfo p){return android.os.Build.VERSION.SDK_INT>=28&&p.signingInfo!=null?p.signingInfo.getApkContentsSigners():p.signatures;}
 private void checkUpdate(){
  if(exiting||checkingUpdate||System.currentTimeMillis()-lastUpdateCheck<60000)return;checkingUpdate=true;lastUpdateCheck=System.currentTimeMillis();
  new Thread(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(ROOT+"api/version").openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(4000);c.setReadTimeout(4000);if(c.getResponseCode()!=200)return;ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))!=-1){bytes.write(buffer,0,n);if(bytes.size()>64000)return;}}org.json.JSONObject info=new org.json.JSONObject(bytes.toString("UTF-8"));long installed=appVersion(getPackageManager().getPackageInfo(getPackageName(),0));if(info.optLong("android_version",0)>installed&&!info.optBoolean("busy",false))runOnUiThread(()->{if(!exiting&&!isFinishing())new AlertDialog.Builder(this).setTitle("Atualização do Reserva").setMessage("Há uma atualização disponível na sua máquina virtual. Instalar agora?").setPositiveButton("Atualizar",(d,w)->downloadUpdate()).setNegativeButton("Depois",null).show();});}catch(Exception ignored){}finally{if(c!=null)c.disconnect();checkingUpdate=false;}},"fsj-update-check").start();
 }
 private void downloadUpdate(){
  Toast.makeText(this,"Baixando atualização da máquina virtual…",Toast.LENGTH_LONG).show();
  new Thread(()->{HttpURLConnection c=null;File temporary=new File(getCacheDir(),"update.part");try{c=(HttpURLConnection)new URL(ROOT+"baixar/android").openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(10000);c.setReadTimeout(10000);if(c.getResponseCode()!=200)throw new IOException("Instalador indisponível na VM");long size=0;try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(temporary)){byte[] buffer=new byte[65536];int n;while((n=in.read(buffer))!=-1){if(exiting)throw new IOException("Aplicativo encerrado");size+=n;if(size>20*1024*1024)throw new IOException("Instalador excede o limite");out.write(buffer,0,n);}}
  android.content.pm.PackageManager pm=getPackageManager();int flags=android.os.Build.VERSION.SDK_INT>=28?android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES:android.content.pm.PackageManager.GET_SIGNATURES;android.content.pm.PackageInfo downloaded=pm.getPackageArchiveInfo(temporary.getAbsolutePath(),flags),installed=pm.getPackageInfo(getPackageName(),flags);
  if(downloaded==null||!getPackageName().equals(downloaded.packageName)||appVersion(downloaded)<=appVersion(installed))throw new IOException("Pacote inválido ou desatualizado");
  android.content.pm.Signature[] ds=signers(downloaded),is=signers(installed);if(ds==null||is==null||ds.length!=1||is.length!=1||!java.util.Arrays.equals(ds[0].toByteArray(),is[0].toByteArray()))throw new IOException("Assinatura do Proprietário não confere");
  File ready=new File(getCacheDir(),"update.apk");if(ready.exists()&&!ready.delete())throw new IOException("Não foi possível substituir o instalador");if(!temporary.renameTo(ready))throw new IOException("Não foi possível preparar o instalador");runOnUiThread(()->{if(!exiting){apkPending=true;installUpdate();}});
  }catch(Exception e){message("Não foi possível atualizar: "+e.getMessage());}finally{temporary.delete();if(c!=null)c.disconnect();}},"fsj-update-download").start();
 }
 private void installUpdate(){
  if(exiting||!apkPending)return;
  if(!getPackageManager().canRequestPackageInstalls()){try{startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+getPackageName())));}catch(Exception e){message("Autorize a instalação de atualizações nas configurações do Android.");}return;}
  apkPending=false;Intent install=new Intent(Intent.ACTION_VIEW);install.setDataAndType(Uri.parse("content://"+getPackageName()+".atualizacao/update.apk"),"application/vnd.android.package-archive");install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivity(install);}catch(Exception e){message("Não foi possível abrir o instalador do Android.");}
 }
 public final class ExitBridge {
  @JavascriptInterface public void exit(){runOnUiThread(()->{if(web!=null&&allowed(web.getUrl()))closeApplication();});}
  @JavascriptInterface public String savedLogin(){final java.util.concurrent.atomic.AtomicReference<String> result=new java.util.concurrent.atomic.AtomicReference<>("{}");final java.util.concurrent.CountDownLatch done=new java.util.concurrent.CountDownLatch(1);runOnUiThread(()->{try{if(!exiting&&web!=null&&allowed(web.getUrl()))result.set(readSavedLogin());}finally{done.countDown();}});try{done.await(2,java.util.concurrent.TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}return result.get();}
  @JavascriptInterface public void saveLogin(String name,String password,boolean remember){runOnUiThread(()->{if(exiting||web==null||!allowed(web.getUrl()))return;android.content.SharedPreferences prefs=getSharedPreferences("saved-login",MODE_PRIVATE);if(!remember){prefs.edit().clear().apply();return;}if(name==null||password==null||name.length()>100||password.length()<10||password.length()>200)return;try{org.json.JSONObject login=new org.json.JSONObject().put("name",name).put("password",password);javax.crypto.Cipher cipher=javax.crypto.Cipher.getInstance("AES/GCM/NoPadding");cipher.init(javax.crypto.Cipher.ENCRYPT_MODE,loginKey());String iv=android.util.Base64.encodeToString(cipher.getIV(),android.util.Base64.NO_WRAP),value=android.util.Base64.encodeToString(cipher.doFinal(login.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8)),android.util.Base64.NO_WRAP);prefs.edit().putString("iv",iv).putString("value",value).apply();}catch(Exception e){prefs.edit().clear().apply();message("Não foi possível salvar o acesso com segurança neste aparelho.");}});}
 }
 private javax.crypto.SecretKey loginKey()throws Exception{java.security.KeyStore store=java.security.KeyStore.getInstance("AndroidKeyStore");store.load(null);String alias="fsj-reserva-login";if(store.containsAlias(alias))return (javax.crypto.SecretKey)store.getKey(alias,null);javax.crypto.KeyGenerator generator=javax.crypto.KeyGenerator.getInstance("AES","AndroidKeyStore");generator.init(new android.security.keystore.KeyGenParameterSpec.Builder(alias,android.security.keystore.KeyProperties.PURPOSE_ENCRYPT|android.security.keystore.KeyProperties.PURPOSE_DECRYPT).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE).build());return generator.generateKey();}
 private String readSavedLogin(){try{android.content.SharedPreferences prefs=getSharedPreferences("saved-login",MODE_PRIVATE);String iv=prefs.getString("iv",null),value=prefs.getString("value",null);if(iv==null||value==null)return "{}";javax.crypto.Cipher cipher=javax.crypto.Cipher.getInstance("AES/GCM/NoPadding");cipher.init(javax.crypto.Cipher.DECRYPT_MODE,loginKey(),new javax.crypto.spec.GCMParameterSpec(128,android.util.Base64.decode(iv,android.util.Base64.NO_WRAP)));return new String(cipher.doFinal(android.util.Base64.decode(value,android.util.Base64.NO_WRAP)),java.nio.charset.StandardCharsets.UTF_8);}catch(Exception e){return "{}";}}

 private void closeApplication(){
  if(exiting)return;exiting=true;
  final String cookie=CookieManager.getInstance().getCookie(ROOT);
  if(mediaRequest!=null){mediaRequest.deny();mediaRequest=null;}
  if(fileCallback!=null){fileCallback.onReceiveValue(null);fileCallback=null;}
  pendingDownload=null;if(activeDownload!=null)activeDownload.disconnect();
  if(web!=null){web.stopLoading();web.onPause();web.removeJavascriptInterface("FSJAndroid");layout.removeView(web);web.destroy();web=null;}
  WebStorage.getInstance().deleteAllData();
  CookieManager.getInstance().removeAllCookies(value->CookieManager.getInstance().flush());
  new Thread(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(ROOT+"api/logout").openConnection();c.setConnectTimeout(2500);c.setReadTimeout(2500);c.setInstanceFollowRedirects(false);c.setRequestMethod("POST");c.setRequestProperty("X-FSJ-Request","1");c.setRequestProperty("Content-Type","application/json");if(cookie!=null)c.setRequestProperty("Cookie",cookie);c.setDoOutput(true);try(OutputStream out=c.getOutputStream()){out.write("{}".getBytes(java.nio.charset.StandardCharsets.UTF_8));}c.getResponseCode();}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}},"fsj-logout").start();
  Intent home=new Intent(Intent.ACTION_MAIN);home.addCategory(Intent.CATEGORY_HOME);home.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);try{startActivity(home);}catch(Exception ignored){}finishAndRemoveTask();
 }
 private void open(){CookieManager.getInstance().flush();sslNotice=false;web.setVisibility(View.VISIBLE);web.onResume();web.loadUrl(ROOT);}
 private void requestMedia(PermissionRequest request){
  if(exiting||!allowed(request.getOrigin().toString())||isFinishing()){request.deny();return;}
  for(String resource:request.getResources())if(!PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)&&!PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)){request.deny();return;}
  if(mediaRequest!=null)mediaRequest.deny();mediaRequest=request;
  java.util.ArrayList<String> missing=new java.util.ArrayList<>();
  for(String resource:request.getResources()){String permission=PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)?android.Manifest.permission.CAMERA:android.Manifest.permission.RECORD_AUDIO;if(checkSelfPermission(permission)!=android.content.pm.PackageManager.PERMISSION_GRANTED)missing.add(permission);}
  if(missing.isEmpty())grantMedia();else requestPermissions(missing.toArray(new String[0]),802);
 }
 private void grantMedia(){PermissionRequest request=mediaRequest;mediaRequest=null;if(request==null)return;if(isFinishing()||!allowed(request.getOrigin().toString())){request.deny();return;}for(String resource:request.getResources()){String permission=PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)?android.Manifest.permission.CAMERA:android.Manifest.permission.RECORD_AUDIO;if(checkSelfPermission(permission)!=android.content.pm.PackageManager.PERMISSION_GRANTED){request.deny();return;}}request.grant(request.getResources());}
 @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);if(request==802)grantMedia();}
 private void message(String text){runOnUiThread(()->{if(!isFinishing())new AlertDialog.Builder(this).setMessage(text).setPositiveButton("OK",null).show();});}
 @Override protected void onResume(){super.onResume();if(web!=null)web.onResume();if(apkPending&&getPackageManager().canRequestPackageInstalls())installUpdate();else checkUpdate();}
 @Override protected void onPause(){if(web!=null){if(mediaRequest==null)web.evaluateJavascript("window.fsjCallsPause&&window.fsjCallsPause()",null);CookieManager.getInstance().flush();web.onPause();}super.onPause();}
 @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==700&&fileCallback!=null){Uri[] uris=null;if(result==RESULT_OK&&data!=null&&data.getData()!=null)uris=new Uri[]{data.getData()};fileCallback.onReceiveValue(uris);fileCallback=null;}if(request==701&&result==RESULT_OK&&data!=null&&data.getData()!=null&&pendingDownload!=null){final String url=pendingDownload;final Uri destination=data.getData();pendingDownload=null;final String cookie=CookieManager.getInstance().getCookie(url);new Thread(()->{HttpURLConnection c=null;try{if(!allowed(url))throw new IOException("Destino bloqueado");c=(HttpURLConnection)new URL(url).openConnection();activeDownload=c;c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(30000);if(cookie!=null)c.setRequestProperty("Cookie",cookie);if(c.getResponseCode()!=200)throw new IOException("Download não autorizado ou indisponível");try(InputStream in=c.getInputStream();OutputStream out=getContentResolver().openOutputStream(destination)){if(out==null)throw new IOException("Destino indisponível");byte[] b=new byte[65536];int n;while(!exiting&&(n=in.read(b))!=-1)out.write(b,0,n);}message("Vídeo salvo.");}catch(Exception e){message("Não foi possível salvar: "+e.getMessage());}finally{if(c!=null)c.disconnect();activeDownload=null;}},"fsj-vm-download").start();}}
 @Override protected void onDestroy(){if(mediaRequest!=null){mediaRequest.deny();mediaRequest=null;}if(fileCallback!=null)fileCallback.onReceiveValue(null);if(web!=null){web.removeJavascriptInterface("FSJAndroid");web.stopLoading();web.destroy();}super.onDestroy();}
}
