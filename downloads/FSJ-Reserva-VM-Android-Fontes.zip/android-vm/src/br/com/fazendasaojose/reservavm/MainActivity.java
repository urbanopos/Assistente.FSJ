package br.com.fazendasaojose.reservavm;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.view.View;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

/** Standalone client: every network request must match the owner's configured VM origin. */
public final class MainActivity extends Activity {
 private WebView web; private LinearLayout layout;
 private static final String ROOT="https://192.168.1.114:8443/";
 private final String root=ROOT; private String pendingDownload; private ValueCallback<Uri[]> fileCallback;
 private volatile boolean exiting=false; private volatile HttpURLConnection activeDownload;
 private boolean sslNotice=false; private PermissionRequest mediaRequest;
 private int port(Uri u){return u.getPort()==-1?443:u.getPort();}
 private boolean allowed(String value){try{Uri a=Uri.parse(root),u=Uri.parse(value);return !root.isEmpty()&&"https".equals(u.getScheme())&&a.getHost().equalsIgnoreCase(u.getHost())&&port(a)==port(u)&&u.getUserInfo()==null;}catch(Exception e){return false;}}
 @Override public void onCreate(Bundle state){super.onCreate(state);
  layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setBackgroundColor(Color.rgb(241,245,241));
  web=new WebView(this);layout.addView(web,new LinearLayout.LayoutParams(-1,0,1));setContentView(layout);
  layout.setOnApplyWindowInsetsListener((v,insets)->{if(android.os.Build.VERSION.SDK_INT>=30){android.graphics.Insets i=insets.getInsets(android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.ime());v.setPadding(i.left,i.top,i.right,i.bottom);}else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});
  WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setSupportMultipleWindows(false);s.setSafeBrowsingEnabled(false);s.setMediaPlaybackRequiresUserGesture(false);s.setUserAgentString(s.getUserAgentString()+" FSJReservaVM/V.001-chamadas");CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
  web.addJavascriptInterface(new ExitBridge(),"FSJAndroid");
  web.setWebViewClient(new WebViewClient(){
   @Override public void onPageFinished(WebView view,String url){if(allowed(url)&&!exiting)view.evaluateJavascript("(()=>{if(window.__fsjExitBound)return;window.__fsjExitBound=true;document.addEventListener('click',function(e){if(!e.isTrusted||!e.target.closest||!e.target.closest('#logout'))return;e.preventDefault();e.stopImmediatePropagation();try{window.fsjCallsStop&&window.fsjCallsStop();document.querySelectorAll('video,audio').forEach(v=>{v.pause();if(v.srcObject)v.srcObject.getTracks().forEach(t=>t.stop());v.srcObject=null;v.removeAttribute('src');v.load();});}finally{FSJAndroid.exit();}},true);})()",null);}
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){return !allowed(req.getUrl().toString());}
   @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest req){if(allowed(req.getUrl().toString()))return null;return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",java.util.Collections.emptyMap(),new ByteArrayInputStream("Destino fora da VM bloqueado".getBytes(java.nio.charset.StandardCharsets.UTF_8)));}
   @Override public void onReceivedSslError(WebView view,SslErrorHandler handler,SslError error){handler.cancel();if(!sslNotice){sslNotice=true;message("Certificado não reconhecido ou endereço diferente do certificado. O certificado público da VM já está incluído no aplicativo. Confira a data e a hora do celular; se o erro persistir, avise o Proprietário. A conexão foi bloqueada.");}}
   @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error){if(request.isForMainFrame())message("Não foi possível alcançar a VM. Confira o endereço, a rede e se o servidor está ligado. "+error.getDescription());}
  });
  web.setWebChromeClient(new WebChromeClient(){
   @Override public void onPermissionRequest(PermissionRequest request){runOnUiThread(()->requestMedia(request));}
   @Override public void onPermissionRequestCanceled(PermissionRequest request){runOnUiThread(()->{if(mediaRequest==request)mediaRequest=null;});}

   @Override public boolean onJsConfirm(WebView v,String url,String text,JsResult result){if(!allowed(url)){result.cancel();return true;}new AlertDialog.Builder(MainActivity.this).setMessage(text).setPositiveButton("Confirmar",(d,w)->result.confirm()).setNegativeButton("Cancelar",(d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show();return true;}
   @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> callback,FileChooserParams params){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=callback;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("video/*");try{startActivityForResult(i,700);}catch(Exception e){callback.onReceiveValue(null);fileCallback=null;}return true;}
  });
  web.setDownloadListener((url,agent,disposition,mime,length)->{if(!allowed(url))return;pendingDownload=url;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime==null?"video/mp4":mime);i.putExtra(Intent.EXTRA_TITLE,URLUtil.guessFileName(url,disposition,mime));try{startActivityForResult(i,701);}catch(Exception e){message("Não foi possível abrir o destino do arquivo.");}});
  open();
 }
 public final class ExitBridge { @JavascriptInterface public void exit(){runOnUiThread(()->{if(web!=null&&allowed(web.getUrl()))closeApplication();});} }
 private void closeApplication(){
  if(exiting)return;exiting=true;
  final String cookie=CookieManager.getInstance().getCookie(ROOT);
  if(mediaRequest!=null){mediaRequest.deny();mediaRequest=null;}
  if(fileCallback!=null){fileCallback.onReceiveValue(null);fileCallback=null;}
  pendingDownload=null;if(activeDownload!=null)activeDownload.disconnect();
  if(web!=null){web.stopLoading();web.onPause();web.removeJavascriptInterface("FSJAndroid");layout.removeView(web);web.destroy();web=null;}
  WebStorage.getInstance().deleteAllData();
  CookieManager.getInstance().removeAllCookies(value->CookieManager.getInstance().flush());
  new Thread(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(ROOT+"api/logout").openConnection();c.setConnectTimeout(2500);c.setReadTimeout(2500);c.setRequestMethod("POST");c.setRequestProperty("X-FSJ-Request","1");c.setRequestProperty("Content-Type","application/json");if(cookie!=null)c.setRequestProperty("Cookie",cookie);c.setDoOutput(true);try(OutputStream out=c.getOutputStream()){out.write("{}".getBytes(java.nio.charset.StandardCharsets.UTF_8));}c.getResponseCode();}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}},"fsj-logout").start();
  Intent home=new Intent(Intent.ACTION_MAIN);home.addCategory(Intent.CATEGORY_HOME);home.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);try{startActivity(home);}catch(Exception ignored){}finishAndRemoveTask();
 }
 private void open(){CookieManager.getInstance().flush();sslNotice=false;web.setVisibility(View.VISIBLE);web.onResume();web.loadUrl(ROOT);}
 private void requestMedia(PermissionRequest request){
  if(exiting||!allowed(request.getOrigin().toString())||isFinishing()){request.deny();return;}
  for(String resource:request.getResources())if(!PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)&&!PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)){request.deny();return;}
  if(mediaRequest!=null)mediaRequest.deny();mediaRequest=request;
  java.util.ArrayList<String> missing=new java.util.ArrayList<>();
  for(String resource:request.getResources()){String permission=PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)?android.Manifest.permission.CAMERA:android.Manifest.permission.RECORD_AUDIO;if(checkSelfPermission(permission)!=android.content.pm.PackageManager.PERMISSION_GRANTED)missing.add(permission);}
  if(missing.isEmpty())grantMedia();else requestPermissions(missing.toArray(new String[0]),802);
 }
 private void grantMedia(){PermissionRequest request=mediaRequest;mediaRequest=null;if(request==null)return;if(isFinishing()||!allowed(request.getOrigin().toString())){request.deny();return;}for(String resource:request.getResources()){String permission=PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)?android.Manifest.permission.CAMERA:android.Manifest.permission.RECORD_AUDIO;if(checkSelfPermission(permission)!=android.content.pm.PackageManager.PERMISSION_GRANTED){request.deny();return;}}request.grant(request.getResources());}
 @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);if(request==802)grantMedia();}
 private void message(String text){runOnUiThread(()->{if(!isFinishing())new AlertDialog.Builder(this).setMessage(text).setPositiveButton("OK",null).show();});}
 @Override protected void onResume(){super.onResume();if(web!=null)web.onResume();}
 @Override protected void onPause(){if(web!=null){if(mediaRequest==null)web.evaluateJavascript("window.fsjCallsPause&&window.fsjCallsPause()",null);CookieManager.getInstance().flush();web.onPause();}super.onPause();}
 @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==700&&fileCallback!=null){Uri[] uris=null;if(result==RESULT_OK&&data!=null&&data.getData()!=null)uris=new Uri[]{data.getData()};fileCallback.onReceiveValue(uris);fileCallback=null;}if(request==701&&result==RESULT_OK&&data!=null&&data.getData()!=null&&pendingDownload!=null){final String url=pendingDownload;final Uri destination=data.getData();pendingDownload=null;final String cookie=CookieManager.getInstance().getCookie(url);new Thread(()->{HttpURLConnection c=null;try{if(!allowed(url))throw new IOException("Destino bloqueado");c=(HttpURLConnection)new URL(url).openConnection();activeDownload=c;c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(30000);if(cookie!=null)c.setRequestProperty("Cookie",cookie);if(c.getResponseCode()!=200)throw new IOException("Download não autorizado ou indisponível");try(InputStream in=c.getInputStream();OutputStream out=getContentResolver().openOutputStream(destination)){if(out==null)throw new IOException("Destino indisponível");byte[] b=new byte[65536];int n;while(!exiting&&(n=in.read(b))!=-1)out.write(b,0,n);}message("Vídeo salvo.");}catch(Exception e){message("Não foi possível salvar: "+e.getMessage());}finally{if(c!=null)c.disconnect();activeDownload=null;}},"fsj-vm-download").start();}}
 @Override protected void onDestroy(){if(mediaRequest!=null){mediaRequest.deny();mediaRequest=null;}if(fileCallback!=null)fileCallback.onReceiveValue(null);if(web!=null){web.removeJavascriptInterface("FSJAndroid");web.stopLoading();web.destroy();}super.onDestroy();}
}
