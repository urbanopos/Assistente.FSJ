# Android FSJ Reserva VM · V.001 chamadas

versionCode 3, mesma assinatura anterior. CA pública da VM incorporada; endereço fixo https://192.168.1.114:8443/. Permissões CAMERA e RECORD_AUDIO são solicitadas somente quando uma página do endereço da VM pede captura. Só recursos de áudio/vídeo aprovados pelo Android são concedidos; outros recursos/origens são recusados. Ao ir para segundo plano o cliente sai da chamada.

A implantação e as limitações constam no LEIA-PRIMEIRO.md na raiz do pacote. Build: Android SDK 35, Build Tools 35.0.0, JDK ou ECJ 3.38.0 com Java 17. Forneça FSJ_KEYSTORE/FSJ_STOREPASS da chave privada do proprietário; nenhuma chave privada é distribuída neste pacote.
