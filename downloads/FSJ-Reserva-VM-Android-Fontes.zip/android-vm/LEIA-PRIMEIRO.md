# Android FSJ Reserva VM · V.001 chamadas

versionCode 3, mesma assinatura anterior. CA pública da VM incorporada; endereço fixo https://192.168.1.114:8443/. Permissões CAMERA e RECORD_AUDIO são solicitadas somente quando uma página do endereço da VM pede captura. Só recursos de áudio/vídeo aprovados pelo Android são concedidos; outros recursos/origens são recusados. Ao ir para segundo plano o cliente sai da chamada.

A implantação e as limitações constam no LEIA-PRIMEIRO.md na raiz do pacote. Build: Android SDK 35, Build Tools 35.0.0, JDK ou ECJ 3.38.0 com Java 17. Forneça FSJ_KEYSTORE/FSJ_STOREPASS da chave privada do proprietário; nenhuma chave privada é distribuída neste pacote.

## Atualização Android 5 — Sair
O botão Sair da página da VM é interceptado somente em um clique real. Fecha a WebView, encerra recursos de mídia e seletores de arquivo, interrompe download ativo, limpa cookies e armazenamento do cliente, solicita a revogação da sessão à VM e retorna à tela inicial do Android removendo a tarefa dos recentes. A revogação remota depende de a VM estar alcançável; a remoção da sessão local e o fechamento ocorrem mesmo sem rede. Não usa serviços externos.
O APK mantém assinatura, pacote e certificado público da VM. Nenhuma alteração de layout ou sincronização é aplicada à VM por esta atualização.
Validação: compilação, assinatura, versão e teste do clique em navegador; encerramento nativo no aparelho ainda requer conferência após instalar.
