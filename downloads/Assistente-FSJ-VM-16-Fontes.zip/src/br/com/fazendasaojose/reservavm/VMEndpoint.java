package br.com.fazendasaojose.reservavm;
import android.content.Context;import java.io.*;import java.net.*;import org.json.JSONObject;
final class VMEndpoint {
 static String saved(Context c){return c.getSharedPreferences("fsj-network",0).getString("origin",RoutePolicy.PUBLIC);}
 static String choose(Context ctx)throws IOException{
  String result=RoutePolicy.choose(saved(ctx),origin->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(origin+"api/version").openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(1800);c.setReadTimeout(1800);if(c.getResponseCode()!=200)return false;ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] b=new byte[1024];int n;while((n=in.read(b))!=-1){bytes.write(b,0,n);if(bytes.size()>32000)return false;}}JSONObject info=new JSONObject(bytes.toString("UTF-8"));return info.has("release")&&info.has("android_version");}catch(Exception e){return false;}finally{if(c!=null)c.disconnect();}});
  ctx.getSharedPreferences("fsj-network",0).edit().putString("origin",result).apply();return result;
 }
}
