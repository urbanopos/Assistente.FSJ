package br.com.fazendasaojose.reservavm;
import java.io.IOException;import java.util.LinkedHashSet;import java.util.Arrays;
final class RoutePolicy {
 static final String PUBLIC="https://168.196.84.147/";
 static final String[] ALLOWED={PUBLIC,"https://192.168.1.114:8443/","https://192.168.1.100:8443/","https://192.168.77.2:8443/"};
 interface Probe{boolean reachable(String origin);}
 static String choose(String saved,Probe probe)throws IOException{LinkedHashSet<String> origins=new LinkedHashSet<>();if(Arrays.asList(ALLOWED).contains(saved))origins.add(saved);origins.addAll(Arrays.asList(ALLOWED));for(String origin:origins)if(probe.reachable(origin))return origin;throw new IOException("Servidor da fazenda indisponível. Confira a conexão e tente novamente.");}
}
