package br.com.fazendasaojose.reservavm;
import java.util.*;import java.io.*;
public final class RoutePolicyTest {
 public static void main(String[] args)throws Exception{
  List<String> tried=new ArrayList<>();
  String chosen=RoutePolicy.choose("https://attacker.invalid/",origin->{tried.add(origin);return origin.equals(RoutePolicy.PUBLIC);});
  if(!chosen.equals(RoutePolicy.PUBLIC)||tried.contains("https://attacker.invalid/"))throw new AssertionError("Untrusted saved destination used");
  chosen=RoutePolicy.choose("https://192.168.1.114:8443/",origin->origin.equals(RoutePolicy.PUBLIC));
  if(!chosen.equals(RoutePolicy.PUBLIC))throw new AssertionError("No fallback from local to public");
  chosen=RoutePolicy.choose(RoutePolicy.PUBLIC,origin->origin.equals("https://192.168.77.2:8443/"));
  if(!chosen.equals("https://192.168.77.2:8443/"))throw new AssertionError("VM direct fallback failed");
  try{RoutePolicy.choose(RoutePolicy.PUBLIC,origin->false);throw new AssertionError("Unreachable origin returned");}catch(IOException expected){}
  tried.clear();chosen=RoutePolicy.choose("https://192.168.1.100:8443/",origin->{tried.add(origin);return true;});
  if(tried.size()!=1||!chosen.equals("https://192.168.1.100:8443/"))throw new AssertionError("Working saved route not reused");
  System.out.println("5 cenarios de rede aprovados: destinos limitados, alternancia e falha segura.");
 }
}
