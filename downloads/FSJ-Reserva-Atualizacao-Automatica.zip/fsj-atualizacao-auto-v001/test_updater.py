import unittest,tempfile,json,sqlite3,shutil,importlib.util,sys
from pathlib import Path
from unittest.mock import patch
import updater
HERE=Path(__file__).resolve().parent
CHANNEL=HERE/'test-channel'
class UpdateTests(unittest.TestCase):
 def test_signature_and_tampering(self):
  with tempfile.TemporaryDirectory() as d:
   folder=Path(d);raw=(CHANNEL/'manifest.json').read_bytes();sig=(CHANNEL/'manifest.sig').read_bytes();key=HERE/'update-public.pem'
   m=updater.verify(raw,sig,key,folder);self.assertEqual(m['version'],1)
   with self.assertRaises(Exception):updater.verify(raw+b' ',sig,key,folder)
   new=updater.unpack((CHANNEL/'release-1.zip').read_bytes(),m,folder);self.assertTrue((new/'server.py').is_file())
   with self.assertRaises(ValueError):updater.unpack(b'changed',m,folder)
 def fixture(self,root):
  target=root/'live';source=root/'new';shutil.copytree(HERE/'app',target,ignore=shutil.ignore_patterns('__pycache__'));shutil.copytree(HERE/'app',source,ignore=shutil.ignore_patterns('__pycache__'));(target/'dados').mkdir();
  with sqlite3.connect(target/'dados/fsj.sqlite') as c:c.execute('create table proof(value text)');c.execute("insert into proof values('preservado')")
  return target,source
 def test_static_update_without_restart(self):
  with tempfile.TemporaryDirectory() as d:
   target,source=self.fixture(Path(d));(source/'static/app.js').write_text('/* new */');(source/'version.json').write_text('{"release":2}')
   with patch.object(updater,'service') as service,patch.object(updater,'health',return_value={'release':2}):
    backup=updater.apply(target,source,{'version':2});service.assert_not_called()
   self.assertEqual((target/'static/app.js').read_text(),'/* new */');self.assertTrue((backup/'fsj.sqlite').is_file())
 def test_failed_backend_update_rolls_back(self):
  with tempfile.TemporaryDirectory() as d:
   target,source=self.fixture(Path(d));old=(target/'server.py').read_bytes();(source/'server.py').write_text('raise RuntimeError("broken")');(source/'version.json').write_text('{"release":2}')
   with patch.object(updater,'service') as service,patch.object(updater,'health',return_value=None),patch.object(updater.time,'sleep'):
    with self.assertRaises(RuntimeError):updater.apply(target,source,{'version':2})
    self.assertEqual([c.args[0] for c in service.call_args_list],['stop','start','stop','start'])
   self.assertEqual((target/'server.py').read_bytes(),old)
   with sqlite3.connect(target/'dados/fsj.sqlite') as c:self.assertEqual(c.execute('select value from proof').fetchone()[0],'preservado')
 def test_version_endpoint_and_write_gate(self):
  sys.path.insert(0,str(HERE/'app'));spec=importlib.util.spec_from_file_location('auto_server',HERE/'app/server.py');server=importlib.util.module_from_spec(spec);spec.loader.exec_module(server)
  with tempfile.TemporaryDirectory() as d:
   server.DATA=Path(d);h=object.__new__(server.Handler);h.path='/api/version';h.reply=lambda *a,**kw:kw.get('obj');self.assertEqual(h.do_GET()['android_version'],6)
   h.path='/api/update-check';self.assertTrue(h.do_GET()['ok']);self.assertTrue((server.DATA/'updates/requested').exists())
   (server.DATA/'updates/applying').touch();h.reply=lambda code,*args:code;h._do_POST=lambda:self.fail('Escrita durante atualização');self.assertEqual(h.do_POST(),503);self.assertEqual(server.ACTIVE_POSTS,0)
if __name__=='__main__':unittest.main()
