#!/usr/bin/env python3
"""FSJ Reserva V.001: protótipo local, sem conexões externas."""
import argparse, getpass, hashlib, hmac, json, os, re, secrets, sqlite3, time, ssl, threading
from pathlib import Path
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from calls import CallHub, CallError
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'dados'; MAX=500*1024*1024
SESSIONS={}; ATTEMPTS={}; SESSION_LOCK=threading.RLock()
ACTIVE_POSTS=0; POST_LOCK=threading.RLock()
@contextmanager
def db():
 c=sqlite3.connect(DATA/'fsj.sqlite',timeout=10); c.row_factory=sqlite3.Row
 try:
  with c: yield c
 finally: c.close()
def call_account(uid):
 with db() as c:
  row=c.execute("SELECT id,name,display_name,role FROM users WHERE id=? AND status='active'",(uid,)).fetchone()
  return dict(row) if row else None
CALLS=CallHub(call_account)
def init():
 DATA.mkdir(mode=0o700,exist_ok=True); (DATA/'videos').mkdir(mode=0o700,exist_ok=True)
 with db() as c:
  c.executescript('CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,name TEXT UNIQUE,hash TEXT,salt TEXT,role TEXT); CREATE TABLE IF NOT EXISTS videos(id TEXT PRIMARY KEY,title TEXT,mime TEXT,size INTEGER,institutional INTEGER,allowed TEXT,created REAL);')
  columns={r['name'] for r in c.execute('PRAGMA table_info(users)')}
  for name,definition in {'status':"TEXT NOT NULL DEFAULT 'active'",'display_name':"TEXT NOT NULL DEFAULT ''",'contact':"TEXT NOT NULL DEFAULT ''",'activation_hash':'TEXT','activation_expires':'REAL','created':'REAL'}.items():
   if name not in columns: c.execute('ALTER TABLE users ADD COLUMN '+name+' '+definition)
  c.execute('CREATE UNIQUE INDEX IF NOT EXISTS users_name_lower ON users(lower(name))')
  c.execute('CREATE TABLE IF NOT EXISTS account_audit(id INTEGER PRIMARY KEY, actor TEXT, target TEXT, action TEXT NOT NULL, created REAL NOT NULL)')
  c.execute("UPDATE users SET display_name=name WHERE display_name=''")
 os.chmod(DATA/'fsj.sqlite',0o600)
def password_hash(p,s): return hashlib.scrypt(p.encode(),salt=bytes.fromhex(s),n=16384,r=8,p=1).hex()
def check_password(p):
 if not isinstance(p,str) or not 10<=len(p)<=200: raise ValueError('Use uma senha de 10 a 200 caracteres.')
def adduser(name,p,role):
 check_password(p)
 salt=secrets.token_hex(16)
 with db() as c: c.execute('INSERT INTO users(id,name,hash,salt,role,status,display_name,created) VALUES(?,?,?,?,?,?,?,?)',(secrets.token_hex(12),name,password_hash(p,salt),salt,role,'active',name,time.time()))
def digest(value): return hashlib.sha256(value.encode()).hexdigest()
def throttle(key,limit=10,window=300):
 now=time.time()
 with SESSION_LOCK:
  # All attempts, including successes, count; memory use is bounded.
  if len(ATTEMPTS)>10000:
   for k in list(ATTEMPTS):
    if not ATTEMPTS[k] or ATTEMPTS[k][-1]<now-900: ATTEMPTS.pop(k,None)
  attempts=[x for x in ATTEMPTS.get(key,[]) if x>now-window]
  if len(attempts)>=limit: return False
  ATTEMPTS[key]=attempts+[now]; return True
def revoke(uid):
 CALLS.revoke(uid)
 with SESSION_LOCK:
  for token,(ident,expires) in list(SESSIONS.items()):
   if ident==uid: SESSIONS.pop(token,None)
def audit(c,actor,target,action): c.execute('INSERT INTO account_audit(actor,target,action,created) VALUES(?,?,?,?)',(actor,target,action,time.time()))
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args): pass
 def reply(self,status=200,obj=None):
  raw=json.dumps(obj or {},ensure_ascii=False).encode(); self.send_response(status); self.headers_common(); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw)
 def headers_common(self):
  self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Referrer-Policy','no-referrer'); self.send_header('X-Frame-Options','DENY')
 def session_token(self):
  for part in self.headers.get('Cookie','').split(';'):
   if part.strip().startswith('fsj_session='): return part.strip().split('=',1)[1]
  return None
 def user(self):
  token=self.session_token()
  with SESSION_LOCK: session=SESSIONS.get(token)
  if not session or session[1]<=time.time():
   with SESSION_LOCK: SESSIONS.pop(token,None)
   return None
  with db() as c: u=c.execute("SELECT id,name,role,display_name FROM users WHERE id=? AND status='active'",(session[0],)).fetchone()
  return dict(u) if u else None
 def body(self):
  n=int(self.headers.get('Content-Length','0'))
  if not 0<n<=32768: raise ValueError('Pedido inválido')
  data=json.loads(self.rfile.read(n))
  if not isinstance(data,dict): raise ValueError('Pedido inválido')
  return data
 def set_session(self,uid):
  token=secrets.token_urlsafe(32)
  with SESSION_LOCK:
   for k,(_,expires) in list(SESSIONS.items()):
    if expires<time.time(): SESSIONS.pop(k,None)
   SESSIONS[token]=(uid,time.time()+28800)
  self.send_response(200); self.headers_common()
  secure='; Secure' if isinstance(self.connection,ssl.SSLSocket) else ''
  self.send_header('Set-Cookie','fsj_session='+token+'; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800'+secure)
  self.send_header('Content-Type','application/json'); self.send_header('Content-Length','2'); self.end_headers(); self.wfile.write(b'{}')
 def do_POST(self):
  global ACTIVE_POSTS
  with POST_LOCK: ACTIVE_POSTS+=1
  try:
   if (DATA/'updates/applying').exists(): return self.reply(503,{'error':'Atualização em andamento. Tente novamente em alguns segundos.'})
   return self._do_POST()
  finally:
   with POST_LOCK: ACTIVE_POSTS-=1
 def _do_POST(self):
  # Custom header + same-origin checks prevent cross-site writes, including raw uploads.
  origin=self.headers.get('Origin')
  if self.headers.get('X-FSJ-Request')!='1' or (origin and urlparse(origin).netloc!=self.headers.get('Host')): return self.reply(403,{'error':'Origem inválida'})
  try: self.post()
  except (ValueError,KeyError,TypeError,AttributeError,sqlite3.IntegrityError): self.reply(400,{'error':'Dados inválidos, nome já utilizado ou senha com menos de 10 caracteres.'})
 def post(self):
  path=urlparse(self.path).path; user=self.user()
  if path=='/api/request-access':
   if not throttle(('request',self.client_address[0]),5,900): return self.reply(429,{'error':'Aguarde quinze minutos antes de solicitar novamente.'})
   d=self.body(); name=str(d.get('name','')).strip().lower(); display=str(d.get('display_name','')).strip(); contact=str(d.get('contact','')).strip()
   if not re.fullmatch(r'[a-z0-9._-]{3,40}',name) or not 3<=len(display)<=100 or not 5<=len(contact)<=100: return self.reply(400,{'error':'Informe nome completo, contato e login de 3 a 40 letras, números, ponto, traço ou sublinhado.'})
   token=secrets.token_urlsafe(32); uid=secrets.token_hex(12)
   with db() as c:
    if c.execute('SELECT 1 FROM users WHERE lower(name)=?',(name,)).fetchone(): return self.reply(409,{'error':'Login indisponível. Se já solicitou, consulte o pedido neste aparelho ou fale com o Proprietário.'})
    c.execute("INSERT INTO users(id,name,hash,salt,role,status,display_name,contact,activation_hash,created) VALUES(?,?,?,?,'viewer','pending',?,?,?,?)",(uid,name,'','',display,contact,digest(token),time.time()))
    audit(c,None,uid,'request')
   return self.reply(201,{'activation':token,'status':'pending'})
  if path in ('/api/request-status','/api/create-password'):
   if not throttle(('activation',self.client_address[0]),60,300): return self.reply(429,{'error':'Aguarde antes de consultar novamente.'})
   d=self.body(); token=str(d.get('activation',''))
   if not re.fullmatch(r'[A-Za-z0-9_-]{43}',token): return self.reply(403,{'error':'Pedido não encontrado neste aparelho.'})
   with db() as c:
    c.execute('BEGIN IMMEDIATE')
    u=c.execute('SELECT * FROM users WHERE activation_hash=?',(digest(token),)).fetchone()
    if not u: return self.reply(403,{'error':'Pedido encerrado ou inválido. Entre com sua senha ou procure o Proprietário.'})
    if path=='/api/request-status': return self.reply(obj={'status':u['status'],'name':u['name'],'expired':bool(u['activation_expires'] and u['activation_expires']<time.time())})
    if u['status']!='approved' or not u['activation_expires'] or u['activation_expires']<time.time(): return self.reply(403,{'error':'A criação da senha depende de autorização vigente do Proprietário.'})
    password=d.get('password'); check_password(password); salt=secrets.token_hex(16)
    c.execute("UPDATE users SET hash=?,salt=?,status='active',activation_hash=NULL,activation_expires=NULL WHERE id=?",(password_hash(password,salt),salt,u['id']))
    audit(c,u['id'],u['id'],'password-created')
   return self.set_session(u['id'])
  if path=='/api/login':
   d=self.body(); name=str(d.get('name','')).strip().lower(); password=d.get('password','')
   if not isinstance(password,str) or len(password)>200: return self.reply(400,{'error':'Dados inválidos'})
   if not throttle(('login-ip',self.client_address[0]),30) or not throttle(('login-user',name),10): return self.reply(429,{'error':'Aguarde cinco minutos antes de tentar novamente.'})
   with db() as c: u=c.execute('SELECT * FROM users WHERE lower(name)=?',(name,)).fetchone()
   # Execute the same slow hash for unknown and inactive users.
   salt=u['salt'] if u and u['salt'] else '00'*16
   calculated=password_hash(password,salt)
   if not u or u['status']!='active' or not hmac.compare_digest(u['hash'],calculated): return self.reply(401,{'error':'Login ou senha incorretos, ou acesso ainda não autorizado.'})
   return self.set_session(u['id'])
  if not user: return self.reply(401,{'error':'Entre para continuar. Sua sessão pode ter expirado ou sido bloqueada.'})
  if path=='/api/logout':
   revoke(user['id']); return self.reply()
  if path.startswith('/api/calls/'):
   try: return self.reply(obj=CALLS.post(user,path.rsplit('/',1)[-1],self.body()))
   except CallError as e: return self.reply(e.status,{'error':str(e)})
  if user['role']!='owner': return self.reply(403,{'error':'Apenas o Proprietário pode realizar esta ação'})
  if path=='/api/account-action':
   d=self.body(); uid=str(d.get('id','')); action=d.get('action')
   if action not in ('approve','reject','block','unblock','delete'): return self.reply(400,{'error':'Ação inválida'})
   with db() as c:
    c.execute('BEGIN IMMEDIATE'); target=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
    if not target: return self.reply(404,{'error':'Conta não encontrada'})
    if target['role']=='owner' or uid==user['id']: return self.reply(403,{'error':'A conta do Proprietário está protegida.'})
    current=target['status']
    if action=='delete':
     for video in c.execute("SELECT id,allowed FROM videos WHERE allowed!='*'").fetchall():
      allowed=','.join(x for x in video['allowed'].split(',') if x!=uid)
      c.execute('UPDATE videos SET allowed=? WHERE id=?',(allowed,video['id']))
     c.execute('DELETE FROM users WHERE id=?',(uid,))
    elif action=='approve' and current in ('pending','rejected','approved') and target['activation_hash']:
     c.execute("UPDATE users SET status='approved',activation_expires=? WHERE id=?",(time.time()+7*86400,uid))
    elif action=='reject' and current in ('pending','approved'):
     c.execute("UPDATE users SET status='rejected',activation_expires=NULL WHERE id=?",(uid,))
    elif action=='block' and current in ('active','approved'):
     c.execute("UPDATE users SET status='blocked' WHERE id=?",(uid,))
    elif action=='unblock' and current=='blocked':
     c.execute('UPDATE users SET status=?,activation_expires=? WHERE id=?',('active' if target['hash'] else 'approved',None if target['hash'] else time.time()+7*86400,uid))
    else: return self.reply(409,{'error':'Ação incompatível com o estado atual da conta.'})
    audit(c,user['id'],uid,action)
   revoke(uid); return self.reply(obj={'ok':True})
  # Legacy owner-created participants are preserved; new participants choose their own password.
  if path=='/api/users': return self.reply(410,{'error':'Use a solicitação e a aprovação de acesso.'})
  if path=='/api/upload':
   q=parse_qs(urlparse(self.path).query); title=q.get('title',[''])[0].strip(); inst=q.get('institutional',['0'])[0]=='1'; allowed=q.get('allowed',[''])[0]
   mime=self.headers.get('Content-Type','').split(';')[0]; n=int(self.headers.get('Content-Length','0'))
   if not title or len(title)>160 or mime not in ('video/mp4','video/webm') or not 0<n<=MAX: return self.reply(400,{'error':'Use MP4 ou WebM de até 500 MB e informe um título.'})
   if allowed!='*':
    ids=[x for x in allowed.split(',') if x]
    with db() as c: known={x['id'] for x in c.execute("SELECT id FROM users WHERE role='viewer' AND status='active'")}
    if not set(ids)<=known: return self.reply(400,{'error':'Participantes inválidos'})
   ident=secrets.token_hex(16); temp=DATA/'videos'/(ident+'.part'); target=DATA/'videos'/ident
   try:
    with temp.open('xb') as f:
     left=n
     while left:
      chunk=self.rfile.read(min(left,1024*1024))
      if not chunk: raise ValueError('Envio interrompido')
      f.write(chunk); left-=len(chunk)
     f.flush(); os.fsync(f.fileno())
    with temp.open('rb') as f: magic=f.read(32)
    if not ((mime=='video/mp4' and magic[4:8]==b'ftyp') or (mime=='video/webm' and magic[:4]==b'\x1aE\xdf\xa3')): raise ValueError('Formato de vídeo inválido')
    temp.rename(target)
    with db() as c:
     if inst: c.execute('UPDATE videos SET institutional=0 WHERE institutional=1')
     c.execute('INSERT INTO videos VALUES(?,?,?,?,?,?,?)',(ident,title,mime,n,int(inst),'*' if inst else allowed,time.time()))
   finally: temp.unlink(missing_ok=True)
   return self.reply(201,{'ok':True})
  return self.reply(404)
 def do_GET(self):
  path=urlparse(self.path).path
  if path=='/api/version':
   try: version=json.loads((ROOT/'version.json').read_text())
   except (OSError,ValueError): version={'release':0,'android_version':5,'web_version':'legado'}
   with CALLS.lock:
    CALLS._prune(); version['busy']=any(room['peers'] for room in CALLS.rooms.values())
   with POST_LOCK: version['busy']=version['busy'] or ACTIVE_POSTS>0
   return self.reply(obj=version)
  if path=='/api/update-check':
   request=DATA/'updates/requested'; request.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
   if not request.exists() or time.time()-request.stat().st_mtime>60: request.touch()
   return self.reply(obj={'ok':True})
  if path=='/baixar/android':
   apk=ROOT/'releases'/'FSJ-Reserva-VM-V001-Simples.apk'
   if not apk.is_file(): return self.reply(503,{'error':'Instalador temporariamente indisponível. Avise o Proprietário.'})
   raw=apk.read_bytes(); self.send_response(200); self.headers_common()
   self.send_header('Content-Type','application/vnd.android.package-archive')
   self.send_header('Content-Disposition','attachment; filename="FSJ-Reserva-VM-V001-Simples.apk"')
   self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw); return
  if path in ('/','/app.js','/calls.js','/style.css','/logo.webp'):
   p=ROOT/'static'/({'/':'index.html'}.get(path,path[1:])); types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css','.webp':'image/webp'}; raw=p.read_bytes()
   self.send_response(200); self.headers_common(); self.send_header('Permissions-Policy','camera=(self), microphone=(self), display-capture=()'); self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; media-src 'self' blob:; img-src 'self'; frame-ancestors 'none'; base-uri 'none'"); self.send_header('Content-Type',types[p.suffix]); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw); return
  user=self.user()
  if not user: return self.reply(401,{'error':'Entre para continuar'})
  if path=='/api/me': return self.reply(obj=user)
  if path=='/api/calls': return self.reply(obj=CALLS.list(user))
  if path=='/api/users':
   if user['role']!='owner': return self.reply(403)
   with db() as c: rows=[dict(x) for x in c.execute("SELECT id,name,display_name,contact,status,created FROM users WHERE role='viewer' ORDER BY created DESC,name")]
   return self.reply(obj={'users':rows})
  if path=='/api/videos':
   with db() as c: rows=[dict(x) for x in c.execute('SELECT * FROM videos ORDER BY created DESC')]
   rows=[x for x in rows if self.allowed(user,x)]
   return self.reply(obj={'videos':rows})
  match=re.fullmatch(r'/(media|download)/([a-f0-9]{32})',path)
  if not match: return self.reply(404)
  with db() as c: video=c.execute('SELECT * FROM videos WHERE id=?',(match[2],)).fetchone()
  if not video or not self.allowed(user,video): return self.reply(404)
  if match[1]=='download' and user['role']!='owner': return self.reply(403)
  p=DATA/'videos'/video['id']; total=p.stat().st_size; start=0; end=total-1; partial=False
  ran=self.headers.get('Range')
  if ran:
   m=re.fullmatch(r'bytes=(\d+)-(\d*)',ran)
   if not m: return self.reply(416)
   start=int(m[1]); end=min(int(m[2]) if m[2] else end,end); partial=True
   if start>end: return self.reply(416)
  self.send_response(206 if partial else 200); self.headers_common(); self.send_header('Content-Type',video['mime']); self.send_header('Accept-Ranges','bytes'); self.send_header('Content-Length',str(end-start+1))
  if partial: self.send_header('Content-Range',f'bytes {start}-{end}/{total}')
  if match[1]=='download': self.send_header('Content-Disposition','attachment; filename="FSJ-video.'+('mp4' if video['mime']=='video/mp4' else 'webm')+'"')
  self.end_headers()
  try:
   with p.open('rb') as f:
    f.seek(start); left=end-start+1
    while left:
     block=f.read(min(left,256*1024))
     if not block: break
     if not self.user(): break
     self.wfile.write(block); left-=len(block)
  except (BrokenPipeError,ConnectionResetError): pass
 @staticmethod
 def allowed(u,v): return u['role']=='owner' or v['allowed']=='*' or u['id'] in v['allowed'].split(',')
if __name__=='__main__':
 os.umask(0o077); init(); ap=argparse.ArgumentParser(); ap.add_argument('--setup',action='store_true'); ap.add_argument('--port',type=int,default=8091); ap.add_argument('--host',default='127.0.0.1'); ap.add_argument('--certfile'); ap.add_argument('--keyfile'); args=ap.parse_args()
 if args.setup:
  with db() as c: exists=c.execute("SELECT 1 FROM users WHERE role='owner'").fetchone()
  if exists: raise SystemExit('Proprietário já cadastrado; nenhuma alteração realizada.')
  name=input('Login do Proprietário: ').strip(); p=getpass.getpass('Senha (mínimo 10 caracteres): ')
  if not name or p!=getpass.getpass('Repita a senha: '): raise SystemExit('Dados não conferem')
  adduser(name,p,'owner'); print('Proprietário cadastrado.'); raise SystemExit()
 if bool(args.certfile)!=bool(args.keyfile): raise SystemExit('Informe certificado e chave juntos.')
 if args.host not in ('127.0.0.1','::1','localhost') and not args.certfile: raise SystemExit('Acesso de rede exige HTTPS com --certfile e --keyfile.')
 server=ThreadingHTTPServer((args.host,args.port),Handler)
 if args.certfile:
  context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); context.minimum_version=ssl.TLSVersion.TLSv1_2
  context.load_cert_chain(args.certfile,args.keyfile); server.socket=context.wrap_socket(server.socket,server_side=True)
 print(f"FSJ Reserva V.001 em {'https' if args.certfile else 'http'}://{args.host}:{args.port} — servidor exclusivo da VM",flush=True)
 server.serve_forever()
