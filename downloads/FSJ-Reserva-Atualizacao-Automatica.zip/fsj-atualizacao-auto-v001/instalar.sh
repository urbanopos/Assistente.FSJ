#!/bin/bash
set -eu
umask 077
cd "$(dirname "$0")"
command -v openssl >/dev/null
command -v python3 >/dev/null
command -v systemctl >/dev/null
TASK_FSJ_TARGET="${1:-$HOME/fsj-video-v001}"
[ -f "$TASK_FSJ_TARGET/dados/fsj.sqlite" ] || { echo 'Instalação FSJ anterior não encontrada.'; exit 1; }
[ -f "$TASK_FSJ_TARGET/dados/tls/servidor.crt" ] || { echo 'Certificado HTTPS local não encontrado.'; exit 1; }
# Necessário uma vez para o servidor e o atualizador iniciarem com a VM.
sudo loginctl enable-linger "$(id -un)"
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"
export DBUS_SESSION_BUS_ADDRESS="${DBUS_SESSION_BUS_ADDRESS:-unix:path=$XDG_RUNTIME_DIR/bus}"
python3 - "$TASK_FSJ_TARGET" <<'PY'
from pathlib import Path
import sys,os,subprocess,shutil,sqlite3,datetime,signal,time
source=Path.cwd();target=Path(sys.argv[1]).resolve();units=Path.home()/'.config/systemd/user';units.mkdir(parents=True,exist_ok=True)
backup=target.parent/'fsj-contingencia/backups'/('antes-auto-instalacao-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'));backup.mkdir(parents=True)
subprocess.run(['systemctl','--user','stop','fsj-reserva.service'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
# Encerra somente processos server.py desta instalação, sem atingir outros projetos.
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
 try:
  args=(proc/'cmdline').read_bytes().split(b'\0');cwd=(proc/'cwd').resolve()
  if cwd==target and any(x==b'server.py' or x==str(target/'server.py').encode() for x in args):os.kill(int(proc.name),signal.SIGTERM)
 except (OSError,PermissionError):pass
time.sleep(1)
with sqlite3.connect(target/'dados/fsj.sqlite') as old,sqlite3.connect(backup/'fsj.sqlite') as new:old.backup(new)
for f in (source/'app').rglob('*'):
 if not f.is_file():continue
 rel=f.relative_to(source/'app');dest=target/rel
 if dest.is_file():b=backup/rel;b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dest,b)
 dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest)
local=target/'atualizador';local.mkdir(exist_ok=True);shutil.copy2(source/'updater.py',local/'updater.py');shutil.copy2(source/'update-public.pem',local/'update-public.pem')
request=target/'dados/updates/requested';request.parent.mkdir(mode=0o700,parents=True,exist_ok=True);request.touch();os.chmod(request.parent,0o700)
(units/'fsj-reserva.service').write_text(f'''[Unit]
Description=Assistente FSJ Reserva HTTPS local
After=network-online.target
[Service]
WorkingDirectory={target}
ExecStart=/usr/bin/python3 {target}/server.py --host 0.0.0.0 --port 8443 --certfile dados/tls/servidor.crt --keyfile dados/tls/servidor.key
Restart=on-failure
RestartSec=3
UMask=0077
[Install]
WantedBy=default.target
''')
(units/'fsj-update.service').write_text(f'''[Unit]
Description=Atualizar FSJ por canal assinado
After=fsj-reserva.service
[Service]
Type=oneshot
WorkingDirectory={target}
ExecStart=/usr/bin/python3 {local}/updater.py --target {target} --key {local}/update-public.pem
TimeoutStartSec=120
UMask=0077
''')
(units/'fsj-update.timer').write_text('''[Unit]
Description=Verificar atualizações FSJ periodicamente
[Timer]
OnBootSec=45s
OnUnitActiveSec=2min
Persistent=true
[Install]
WantedBy=timers.target
''')
(units/'fsj-update.path').write_text(f'''[Unit]
Description=Verificar atualizações FSJ ao abrir aplicativo
[Path]
PathChanged={request}
Unit=fsj-update.service
[Install]
WantedBy=default.target
''')
subprocess.run(['systemctl','--user','daemon-reload'],check=True)
try:
 subprocess.run(['systemctl','--user','enable','--now','fsj-reserva.service','fsj-update.timer','fsj-update.path'],check=True)
 time.sleep(1)
 subprocess.run(['systemctl','--user','is-active','--quiet','fsj-reserva.service'],check=True)
except Exception:
 subprocess.run(['systemctl','--user','stop','fsj-reserva.service'])
 for f in backup.rglob('*'):
  if f.is_file() and f.name!='fsj.sqlite':dest=target/f.relative_to(backup);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest)
 shutil.copy2(backup/'fsj.sqlite',target/'dados/fsj.sqlite')
 subprocess.run(['systemctl','--user','start','fsj-reserva.service'])
 raise
print('Rotina automática instalada. Servidor inicia com a VM e verifica atualizações ao abrir o app e a cada dois minutos.')
print('Backup anterior:',backup)
print('Instale uma vez o APK Android 6. Futuras versões serão oferecidas dentro do próprio app.')
PY
