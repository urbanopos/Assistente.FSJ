#!/usr/bin/env python3
"""Canal de atualização assinado, com backup e reversão local."""
import argparse,fcntl,hashlib,http.client,json,os,shutil,sqlite3,ssl,subprocess,tempfile,time,urllib.parse,urllib.request,zipfile
from pathlib import Path
BASE='https://urbanopos.github.io/Assistente.FSJ/downloads/vm/'
ALLOWED={'server.py','calls.py','version.json','static/index.html','static/app.js','static/calls.js','static/style.css','static/logo.webp','releases/FSJ-Reserva-VM-V001-Simples.apk'}
class SafeRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):
  if urllib.parse.urlsplit(newurl).scheme!='https' or urllib.parse.urlsplit(newurl).netloc!='urbanopos.github.io':raise ValueError('Redirecionamento externo bloqueado')
  return super().redirect_request(req,fp,code,msg,headers,newurl)
def download(url,limit):
 if not url.startswith(BASE) or urllib.parse.urlsplit(url).netloc!='urbanopos.github.io':raise ValueError('Canal inválido')
 with urllib.request.build_opener(SafeRedirect()).open(url+'?t='+str(int(time.time())),timeout=20) as r:
  data=r.read(limit+1)
 if len(data)>limit:raise ValueError('Pacote excede o limite')
 return data
def verify(manifest,signature,key,folder):
 m=folder/'manifest.json';s=folder/'manifest.sig';m.write_bytes(manifest);s.write_bytes(signature)
 subprocess.run(['openssl','dgst','-sha256','-verify',str(key),'-signature',str(s),str(m)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 d=json.loads(manifest)
 if not isinstance(d.get('version'),int) or not isinstance(d.get('files'),dict) or set(d['files'])!=ALLOWED:raise ValueError('Manifesto inválido')
 return d
def unpack(data,d,folder):
 if hashlib.sha256(data).hexdigest()!=d['sha256']:raise ValueError('Hash do pacote inválido')
 archive=folder/'package.zip';archive.write_bytes(data)
 with zipfile.ZipFile(archive) as z:
  if len(z.namelist())!=len(ALLOWED) or set(z.namelist())!=ALLOWED:raise ValueError('Conteúdo inesperado no ZIP')
  for info in z.infolist():
   if info.file_size>20*1024*1024 or info.external_attr>>16&0o170000==0o120000:raise ValueError('Arquivo inválido')
   raw=z.read(info.filename)
   if hashlib.sha256(raw).hexdigest()!=d['files'][info.filename]:raise ValueError('Hash de arquivo inválido')
   p=folder/'new'/info.filename;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 for name in ('server.py','calls.py'):compile((folder/'new'/name).read_bytes(),name,'exec')
 version=json.loads((folder/'new/version.json').read_text())
 if version['release']!=d['version']:raise ValueError('Versão divergente')
 return folder/'new'
def health(target):
 context=ssl.create_default_context(cafile=str(target/'dados/tls/fsj-ca.crt'));context.check_hostname=False
 c=http.client.HTTPSConnection('127.0.0.1',8443,context=context,timeout=2)
 try:c.request('GET','/api/version');r=c.getresponse();return json.loads(r.read()) if r.status==200 else None
 finally:c.close()
def service(action):subprocess.run(['systemctl','--user',action,'fsj-reserva.service'],check=True,timeout=20)
def apply(target,source,d):
 backup=target.parent/'fsj-contingencia/backups'/('antes-auto-'+time.strftime('%Y%m%d-%H%M%S'));backup.mkdir(parents=True)
 for name in ALLOWED:
  p=target/name
  if p.is_file():q=backup/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 restart=any(not (target/name).exists() or (target/name).read_bytes()!=(source/name).read_bytes() for name in ('server.py','calls.py'))
 if restart:service('stop')
 try:
  with sqlite3.connect(target/'dados/fsj.sqlite') as old,sqlite3.connect(backup/'fsj.sqlite') as new:old.backup(new)
  for name in sorted(ALLOWED,key=lambda n:(n=='version.json',n=='static/index.html',n)):
   p=target/name;p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.update');shutil.copy2(source/name,tmp);os.replace(tmp,p)
  if restart:service('start')
  ok=False
  for _ in range(15):
   try:
    if (health(target) or {}).get('release')==d['version']:ok=True;break
   except Exception:pass
   time.sleep(.4)
  if not ok:raise RuntimeError('Servidor não passou na verificação')
 except Exception:
  if restart:service('stop')
  for name in ALLOWED:
   p=backup/name
   if p.exists():shutil.copy2(p,target/name)
   else:(target/name).unlink(missing_ok=True)
  if restart and (backup/'fsj.sqlite').exists():shutil.copy2(backup/'fsj.sqlite',target/'dados/fsj.sqlite')
  if restart:service('start')
  raise
 return backup
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--target',required=True);ap.add_argument('--key',required=True);args=ap.parse_args();target=Path(args.target).resolve();data=target/'dados/updates';data.mkdir(mode=0o700,parents=True,exist_ok=True);os.umask(0o077)
 with (data/'lock').open('w') as lock:
  try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:return
  try:
   with tempfile.TemporaryDirectory(dir=data) as tmp:
    folder=Path(tmp);d=verify(download(BASE+'manifest.json',64000),download(BASE+'manifest.sig',8192),Path(args.key),folder)
    current=json.loads((target/'version.json').read_text()).get('release',0)
    if d['version']<=current:return
    state=health(target)
    if state and state.get('busy'):return
    source=unpack(download(d['url'],25*1024*1024),d,folder)
    marker=data/'applying';marker.touch()
    try:
     if (health(target) or {}).get('busy'):return
     backup=apply(target,source,d)
    finally:marker.unlink(missing_ok=True)
    (data/'status.json').write_text(json.dumps({'ok':True,'version':d['version'],'checked':time.time(),'backup':str(backup)}))
  except Exception as e:
   (data/'status.json').write_text(json.dumps({'ok':False,'checked':time.time(),'error':str(e)}));raise
if __name__=='__main__':main()
