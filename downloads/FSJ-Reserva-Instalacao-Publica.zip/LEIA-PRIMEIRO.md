# Assistente FSJ Reserva — Android público 10

O APK inclui o endereço https://168.196.84.147/ e a CA pública da VM. Mantém o pacote e a assinatura anteriores para atualizar sem desinstalar. Não usa GitHub ou Supabase para login, dados ou vídeos. O download inicial usa HTTPS do GitHub Pages para evitar pedir certificado ao usuário.

O proprietário executa instalar.py uma vez na VM com o serviço fsj-reserva ativo. O instalador verifica a CA original, impede alteração durante chamadas/envios, preserva dados e telas atuais, renova apenas o certificado de servidor com o mesmo emissor, instala o APK e atualiza apenas o cartão de instalação. Não altera o servidor Python, banco, sincronização ou sinalização. Em falha de saúde reverte os arquivos substituídos.

Participante Android: toque em Android, abra o download e confirme Instalar. A autorização para instalar desta fonte, se solicitada pelo Android, exige confirmação do usuário. Não é possível confirmar isso silenciosamente pelo site. Não há senha de rede, endereço ou certificado para configurar no telefone.

iPhone: ainda não há instalador nativo assinado pela Apple. A versão web com a CA privada atual exige configuração manual de confiança. Portanto não atende ao objetivo de instalação simples e não é oferecida como equivalente pronta. Será necessário escolher distribuição Apple ou HTTPS reconhecido pelo Safari para concluir esta etapa; nenhum serviço pago foi contratado.

Validação realizada: assinatura APK v2/v3, versão 10 e destino público; testes de preservação de telas/dados e reversão; certificado com SAN público e local. Falta executar na VM real e testar Android em dados móveis. Chamadas entre redes ainda dependem da implantação e teste do TURN na VM. Este pacote não declara chamadas externas concluídas.

Não exponha arquivos .key nem a pasta dados. O certificado expira em 365 dias; a renovação automática ainda não integra este pacote.
