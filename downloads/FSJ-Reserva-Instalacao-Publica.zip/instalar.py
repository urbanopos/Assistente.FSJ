#!/usr/bin/env python3
"""Migração localizada: APK público, certificado e cartão de instalação."""
import contextlib, fcntl, hashlib, http.client, json, os, re, shutil, ssl, subprocess, sys, tempfile, time
from pathlib import Path

PUBLIC = '168.196.84.147'
CA_HASH = '100da28a51f46cb486b3dd28fb46bf75910046bfe2f32fb8e380317d53d2cf13'
HERE = Path(__file__).resolve().parent
CARD = '''<section id="androidDownload" class="card"><h1>Instalar Reserva</h1><p>Escolha seu celular:</p><a class="download-app" href="/baixar/android" download="FSJ-Reserva-Android.apk">Android · instalar aplicativo</a><a id="installIOS" class="download-app" href="https://urbanopos.github.io/Assistente.FSJ/instalar-reserva.html#iphone">iPhone · consultar disponibilidade</a><p class="muted">Android: abra o download e confirme Instalar. Se solicitado, permita esta fonte. O aplicativo já inclui endereço e certificado. iPhone: instalação simplificada ainda indisponível.</p></section>'''

def run(*args):
    return subprocess.run(list(map(str,args)),check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40).stdout

def change_card(text):
    pattern = r'<section\b[^>]*\bid=[\"\']androidDownload[\"\'][^>]*>.*?</section>'
    out, count = re.subn(pattern,lambda _:CARD,text,count=1,flags=re.S)
    if count != 1: raise RuntimeError('Cartão de instalação não identificado; nenhuma tela será substituída.')
    return out

def health(target):
    ctx=ssl.create_default_context(cafile=str(target/'dados/tls/fsj-ca.crt'))
    c=http.client.HTTPSConnection('127.0.0.1',8443,context=ctx,timeout=4)
    try:
        c.request('GET','/api/version');r=c.getresponse()
        if r.status!=200:raise RuntimeError('Servidor não respondeu à verificação.')
        return json.loads(r.read())
    finally:c.close()

def main():
    os.umask(0o077)
    target=Path(sys.argv[1] if len(sys.argv)>1 else '~/fsj-video-v001').expanduser().resolve()
    tls=target/'dados/tls';ca=tls/'fsj-ca.crt';cakey=tls/'fsj-ca.key'
    if not ca.is_file() or not cakey.is_file():raise RuntimeError('Certificado original da VM não encontrado; nenhuma CA será criada.')
    if hashlib.sha256(ssl.PEM_cert_to_DER_cert(ca.read_text())).hexdigest()!=CA_HASH:raise RuntimeError('CA diferente da incorporada no APK. Operação interrompida.')
    expected=(HERE/'APK.sha256').read_text().strip()
    apk=HERE/'FSJ-Reserva-Android.apk'
    if hashlib.sha256(apk.read_bytes()).hexdigest()!=expected:raise RuntimeError('APK inválido.')
    index=target/'static/index.html';new_index=change_card(index.read_text())
    version=target/'version.json';info=json.loads(version.read_text())
    if info.get('android_version',0)>10:raise RuntimeError('Já existe Android mais recente; instalação interrompida.')
    lock_path=target/'dados/updates/lock';lock_path.parent.mkdir(parents=True,exist_ok=True)
    with lock_path.open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if health(target).get('busy'):raise RuntimeError('Há chamada, vídeo em grupo ou envio em andamento. Tente após terminar.')
        backup=target.parent/'fsj-contingencia/backups'/('antes-publico-'+time.strftime('%Y%m%d-%H%M%S')+'-'+os.urandom(3).hex())
        backup.mkdir(parents=True,mode=0o700)
        names=['dados/tls/servidor.crt','dados/tls/servidor.key','static/index.html','version.json','releases/FSJ-Reserva-VM-V001-Simples.apk']
        existed={name:(target/name).exists() for name in names}
        for name in names:
            if existed[name]:
                dest=backup/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target/name,dest)
        with tempfile.TemporaryDirectory(dir=tls) as folder:
            f=Path(folder)
            ext=f/'leaf.ext';ext.write_text('basicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\nsubjectAltName=IP:'+PUBLIC+',IP:192.168.1.114,IP:192.168.77.2,IP:127.0.0.1,DNS:fsj-backend.local\n')
            run('openssl','req','-new','-newkey','rsa:3072','-nodes','-keyout',f/'key','-out',f/'csr','-subj','/CN=Assistente FSJ Reserva/O=Fazenda Sao Jose')
            run('openssl','x509','-req','-in',f/'csr','-CA',ca,'-CAkey',cakey,'-set_serial','0x'+os.urandom(16).hex(),'-out',f/'cert','-days','365','-sha256','-extfile',ext)
            run('openssl','verify','-CAfile',ca,'-verify_ip',PUBLIC,f/'cert')
            run('systemctl','--user','stop','fsj-reserva.service')
            try:
                for src,dst in [(f/'cert',tls/'servidor.crt'),(f/'key',tls/'servidor.key'),(apk,target/names[-1])]:
                    dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst);dst.chmod(0o600)
                index.write_text(new_index)
                info['android_version']=10;version.write_text(json.dumps(info,ensure_ascii=False))
                run('systemctl','--user','start','fsj-reserva.service')
                for attempt in range(20):
                    try:
                        if health(target).get('android_version')==10:break
                    except (OSError,ValueError,RuntimeError):pass
                    time.sleep(.5)
                else:raise RuntimeError('Verificação do servidor falhou.')
            except Exception:
                run('systemctl','--user','stop','fsj-reserva.service')
                for name in names:
                    if existed[name]:shutil.copy2(backup/name,target/name)
                    else:(target/name).unlink(missing_ok=True)
                run('systemctl','--user','start','fsj-reserva.service')
                raise
        print('CONCLUÍDO: Android 10, endereço público e certificado instalados.')
        print('Banco, contas, vídeos, tarefas e demais telas preservados.')
        print('Backup:',backup)
        print('Link para os participantes: https://urbanopos.github.io/Assistente.FSJ/instalar-reserva.html')

if __name__=='__main__':
    try:main()
    except Exception as e:raise SystemExit('NÃO APLICADO OU REVERTIDO: '+str(e))
