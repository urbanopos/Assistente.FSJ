#!/bin/bash
set -eu
cd "$(dirname "$0")"
TASK_SDK=${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}
if [ -z "$TASK_SDK" ]; then echo 'Defina ANDROID_SDK_ROOT com platforms;android-35 e build-tools;35.0.0.' >&2; exit 1; fi
: "${FSJ_KEYSTORE:?Informe FSJ_KEYSTORE com a chave de assinatura do Proprietário}"
: "${FSJ_STOREPASS:?Informe FSJ_STOREPASS}"
TASK_BT="$TASK_SDK/build-tools/35.0.0"
rm -rf build
mkdir -p build/classes build/dex build/generated
"$TASK_BT/aapt" package -f -M AndroidManifest.xml -S res -I "$TASK_SDK/platforms/android-35/android.jar" -J build/generated -F build/resources.apk
if [ -n "${ECJ_JAR:-}" ]; then
 java -jar "$ECJ_JAR" -source 1.8 -target 1.8 -classpath "$TASK_SDK/platforms/android-35/android.jar" -d build/classes $(find src build/generated -name '*.java')
else
 javac -source 8 -target 8 -classpath "$TASK_SDK/platforms/android-35/android.jar" -d build/classes $(find src build/generated -name '*.java')
fi
"$TASK_BT/d8" --lib "$TASK_SDK/platforms/android-35/android.jar" --min-api 26 --output build/dex $(find build/classes -name '*.class')
cp build/resources.apk build/unsigned.apk
(cd build/dex && zip -q ../unsigned.apk classes.dex)
"$TASK_BT/zipalign" -f -p 4 build/unsigned.apk build/aligned.apk
"$TASK_BT/apksigner" sign --ks "$FSJ_KEYSTORE" --ks-key-alias fsj-vm --ks-pass env:FSJ_STOREPASS --out FSJ-Reserva-VM-V001-Simples.apk build/aligned.apk
"$TASK_BT/apksigner" verify --verbose --print-certs FSJ-Reserva-VM-V001-Simples.apk
