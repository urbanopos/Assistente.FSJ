package br.com.fazendasaojose.reservavm;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.view.*;import android.widget.*;
public final class IncomingCallActivity extends Activity {
 private static java.lang.ref.WeakReference<IncomingCallActivity> current=new java.lang.ref.WeakReference<>(null);
 static void dismiss(){IncomingCallActivity a=current.get();if(a!=null)a.runOnUiThread(()->a.finish());}
 @Override public void onCreate(Bundle b){super.onCreate(b);current=new java.lang.ref.WeakReference<>(this);if(Build.VERSION.SDK_INT>=27){setShowWhenLocked(true);setTurnScreenOn(true);}else getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
  String room=getIntent().getStringExtra("room");if(room==null||room.isEmpty()){finish();return;}
  LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setGravity(Gravity.CENTER);box.setPadding(32,32,32,32);box.setBackgroundColor(Color.rgb(15,75,59));
  TextView title=new TextView(this);title.setText("Assistente FSJ\nChamada recebida");title.setTextSize(27);title.setTextColor(Color.WHITE);title.setGravity(Gravity.CENTER);box.addView(title);
  TextView caller=new TextView(this);caller.setText(getIntent().getStringExtra("caller"));caller.setTextSize(23);caller.setTextColor(Color.WHITE);caller.setGravity(Gravity.CENTER);box.addView(caller);
  Button accept=new Button(this);accept.setText("Atender");box.addView(accept,new LinearLayout.LayoutParams(-1,(int)(60*getResources().getDisplayMetrics().density)));accept.setOnClickListener(v->{Intent i=new Intent(this,MainActivity.class).putExtra("fsj_answer",room);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);finish();});
  Button refuse=new Button(this);refuse.setText("Recusar");box.addView(refuse,new LinearLayout.LayoutParams(-1,(int)(60*getResources().getDisplayMetrics().density)));refuse.setOnClickListener(v->{Intent i=new Intent(this,CallReceiverService.class).setAction("ignore").putExtra("room",room);startService(i);finish();});setContentView(box);new Handler(Looper.getMainLooper()).postDelayed(()->finish(),45000);
 }
}
