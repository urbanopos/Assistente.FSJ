package br.com.fazendasaojose.reservavm;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.view.View;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

/** Standalone client: every network request must match the owner's configured VM origin. */
public final class MainActivity extends Activity {
 private WebView web; private LinearLayout layout; private View fullscreenView; private WebChromeClient.CustomViewCallback fullscreenCallback; private int fullscreenFlags;
 private static final String ROOT="https://192.168.1.114:8443/";
 private final String root=ROOT; private String pendingDownload; private ValueCallback<Uri[]> fileCallback;
 private volatile boolean downloadingAPK=false;private long expectedUpdate=0;private final android.os.Handler updateHandler=new android.os.Handler(android.os.Looper.getMainLooper());private final Runnable updateTicker=new Runnable(){public void run(){checkUpdate();updateHandler.postDelayed(this,60000);}};
 private volatile boolean checkingUpdate=false; private long lastUpdateCheck=0; private boolean apkPending=false;
 private volatile boolean exiting=false; private volatile HttpURLConnection activeDownload;
 private String pendingCallAnswer="";private boolean callsPermissionAsked=false;private boolean answerSession=false;private String currentAnswerRoom="";private final java.util.concurrent.atomic.AtomicBoolean answering=new java.util.concurrent.atomic.AtomicBoolean(false);private String lastBoundCookie="";private final java.util.concurrent.atomic.AtomicBoolean binding=new java.util.concurrent.atomic.AtomicBoolean(false);
 private boolean sslNotice=false; private PermissionRequest mediaRequest;
 private int port(Uri u){return u.getPort()==-1?443:u.getPort();}
 private boolean allowed(String value){try{Uri a=Uri.parse(root),u=Uri.parse(value);return !root.isEmpty()&&"https".equals(u.getScheme())&&a.getHost().equalsIgnoreCase(u.getHost())&&port(a)==port(u)&&u.getUserInfo()==null;}catch(Exception e){return false;}}
 @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);if(intent.hasExtra("fsj_answer")){pendingCallAnswer=intent.getStringExtra("fsj_answer");if(web!=null)answerCall();return;}if(web!=null&&!exiting&&allowed(web.getUrl()))web.evaluateJavascript("(()=>{const live=document.getElementById('callLive');if(live&&!live.hidden)return;document.getElementById('goVideos')?.click();})()",null);}
 @Override public void onCreate(Bundle state){super.onCreate(state);pendingCallAnswer=getIntent().getStringExtra("fsj_answer");if(pendingCallAnswer==null)pendingCallAnswer="";
  layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setBackgroundColor(Color.rgb(241,245,241));
  web=new WebView(this);layout.addView(web,new LinearLayout.LayoutParams(-1,0,1));setContentView(layout);
  layout.setOnApplyWindowInsetsListener((v,insets)->{if(android.os.Build.VERSION.SDK_INT>=30){android.graphics.Insets i=insets.getInsets(android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.ime());v.setPadding(i.left,i.top,i.right,i.bottom);}else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});
  WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setSupportMultipleWindows(false);s.setSafeBrowsingEnabled(false);s.setMediaPlaybackRequiresUserGesture(false);s.setUserAgentString(s.getUserAgentString()+" FSJReservaVM/14");CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
  web.addJavascriptInterface(new ExitBridge(),"FSJAndroid");
  web.setWebViewClient(new WebViewClient(){
   @Override public void onPageFinished(WebView view,String url){if(!allowed(url)||exiting)return;view.evaluateJavascript("(()=>{if(window.__fsjAndroid12)return;window.__fsjAndroid12=true;document.addEventListener('fsj:session',()=>FSJAndroid.sessionReady());document.addEventListener('fsj:call-ended',()=>FSJAndroid.callEnded());document.addEventListener('click',e=>{if(e.isTrusted&&e.target.closest?.('#logout')){e.preventDefault();e.stopImmediatePropagation();FSJAndroid.exit();}},true);if(window.fsjCurrentUser)FSJAndroid.sessionReady();})()",null);}
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){return !allowed(req.getUrl().toString());}
   @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest req){if(allowed(req.getUrl().toString()))return null;return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",java.util.Collections.emptyMap(),new ByteArrayInputStream("Destino fora da VM bloqueado".getBytes(java.nio.charset.StandardCharsets.UTF_8)));}
   @Override public void onReceivedSslError(WebView view,SslErrorHandler handler,SslError error){handler.cancel();if(!sslNotice){sslNotice=true;message("Certificado não reconhecido ou endereço diferente do certificado. O certificado público da VM já está incluído no aplicativo. Confira a data e a hora do celular; se o erro persistir, avise o Proprietário. A conexão foi bloqueada.");}}
   @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error){if(request.isForMainFrame())message("Não foi possível alcançar a VM. Confira o endereço, a rede e se o servidor está ligado. "+error.getDescription());}
  });
  web.setWebChromeClient(new WebChromeClient(){
   @Override public void onShowCustomView(View view,CustomViewCallback callback){if(fullscreenView!=null){callback.onCustomViewHidden();return;}fullscreenView=view;fullscreenCallback=callback;fullscreenFlags=getWindow().getDecorView().getSystemUiVisibility();android.widget.FrameLayout frame=new android.widget.FrameLayout(MainActivity.this);frame.setBackgroundColor(Color.BLACK);frame.addView(view,new android.widget.FrameLayout.LayoutParams(-1,-1));Button exit=new Button(MainActivity.this);exit.setText("⊡");exit.setContentDescription("Sair da tela cheia");int size=(int)(44*getResources().getDisplayMetrics().density);android.widget.FrameLayout.LayoutParams p=new android.widget.FrameLayout.LayoutParams(size,size,android.view.Gravity.TOP|android.view.Gravity.RIGHT);frame.addView(exit,p);exit.setOnClickListener(v->hideFullscreen());setContentView(frame);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);}
   @Override public void onHideCustomView(){hideFullscreen();}
   @Override public void onPermissionRequest(PermissionRequest request){runOnUiThread(()->requestMedia(request));}
   @Override public void onPermissionRequestCanceled(PermissionRequest request){runOnUiThread(()->{if(mediaRequest==request)mediaRequest=null;});}

   @Override public boolean onJsConfirm(WebView v,String url,String text,JsResult result){if(!allowed(url)){result.cancel();return true;}new AlertDialog.Builder(MainActivity.this).setMessage(text).setPositiveButton("Confirmar",(d,w)->result.confirm()).setNegativeButton("Cancelar",(d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show();return true;}
   @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> callback,FileChooserParams params){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=callback;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);String[] accepted=params.getAcceptTypes();i.setType(accepted.length==1&&!accepted[0].isEmpty()?accepted[0]:"video/*");try{startActivityForResult(i,700);}catch(Exception e){callback.onReceiveValue(null);fileCallback=null;}return true;}
  });
  web.setDownloadListener((url,agent,disposition,mime,length)->{if(!allowed(url))return;pendingDownload=url;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime==null?"video/mp4":mime);i.putExtra(Intent.EXTRA_TITLE,URLUtil.guessFileName(url,disposition,mime));try{startActivityForResult(i,701);}catch(Exception e){message("Não foi possível abrir o destino do arquivo.");}});
  if(!pendingCallAnswer.isEmpty())answerCall();else open();
 }

 private void hideFullscreen(){if(fullscreenView==null)return;fullscreenView=null;WebChromeClient.CustomViewCallback callback=fullscreenCallback;fullscreenCallback=null;setContentView(layout);getWindow().getDecorView().setSystemUiVisibility(fullscreenFlags);if(callback!=null)callback.onCustomViewHidden();}
 private long appVersion(android.content.pm.PackageInfo p){return android.os.Build.VERSION.SDK_INT>=28?p.getLongVersionCode():p.versionCode;}
 private android.content.pm.Signature[] signers(android.content.pm.PackageInfo p){return android.os.Build.VERSION.SDK_INT>=28&&p.signingInfo!=null?p.signingInfo.getApkContentsSigners():p.signatures;}
 private void checkUpdate(){
  if(exiting||checkingUpdate||downloadingAPK||answerSession||!pendingCallAnswer.isEmpty()||System.currentTimeMillis()-lastUpdateCheck<60000)return;checkingUpdate=true;lastUpdateCheck=System.currentTimeMillis();
  new Thread(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(ROOT+"api/version").openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(4000);c.setReadTimeout(4000);if(c.getResponseCode()!=200)return;ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))!=-1){bytes.write(buffer,0,n);if(bytes.size()>64000)return;}}org.json.JSONObject info=new org.json.JSONObject(bytes.toString("UTF-8"));long installed=appVersion(getPackageManager().getPackageInfo(getPackageName(),0));long available=info.optLong("android_version",0);if(available>installed&&!info.optBoolean("busy",false)){expectedUpdate=available;runOnUiThread(()->{if(!exiting&&!isFinishing())downloadUpdate();});}}catch(Exception ignored){}finally{if(c!=null)c.disconnect();checkingUpdate=false;}},"fsj-update-check").start();
 }
 private void downloadUpdate(){
  if(downloadingAPK||exiting)return;downloadingAPK=true;
  Toast.makeText(this,"Atualizando FSJ Reserva para a versão "+expectedUpdate+"…",Toast.LENGTH_LONG).show();
  new Thread(()->{HttpURLConnection c=null;File temporary=new File(getCacheDir(),"update.part");try{c=(HttpURLConnection)new URL(ROOT+"baixar/android").openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(10000);c.setReadTimeout(10000);if(c.getResponseCode()!=200)throw new IOException("Instalador indisponível na VM");long size=0;try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(temporary)){byte[] buffer=new byte[65536];int n;while((n=in.read(buffer))!=-1){if(exiting)throw new IOException("Aplicativo encerrado");size+=n;if(size>20*1024*1024)throw new IOException("Instalador excede o limite");out.write(buffer,0,n);}}
  android.content.pm.PackageManager pm=getPackageManager();int flags=android.os.Build.VERSION.SDK_INT>=28?android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES:android.content.pm.PackageManager.GET_SIGNATURES;android.content.pm.PackageInfo downloaded=pm.getPackageArchiveInfo(temporary.getAbsolutePath(),flags),installed=pm.getPackageInfo(getPackageName(),flags);
  if(downloaded==null||!getPackageName().equals(downloaded.packageName)||appVersion(downloaded)<=appVersion(installed)||appVersion(downloaded)<expectedUpdate)throw new IOException("Pacote inválido ou desatualizado");
  android.content.pm.Signature[] ds=signers(downloaded),is=signers(installed);if(ds==null||is==null||ds.length!=1||is.length!=1||!java.util.Arrays.equals(ds[0].toByteArray(),is[0].toByteArray()))throw new IOException("Assinatura do Proprietário não confere");
  File ready=new File(getCacheDir(),"update.apk");if(ready.exists()&&!ready.delete())throw new IOException("Não foi possível substituir o instalador");if(!temporary.renameTo(ready))throw new IOException("Não foi possível preparar o instalador");runOnUiThread(()->{if(!exiting){apkPending=true;installUpdate();}});
  }catch(Exception e){message("Não foi possível atualizar: "+e.getMessage());}finally{temporary.delete();if(c!=null)c.disconnect();downloadingAPK=false;}},"fsj-update-download").start();
 }
 private void installUpdate(){
  if(exiting||!apkPending)return;
  if(!getPackageManager().canRequestPackageInstalls()){try{startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+getPackageName())));}catch(Exception e){message("Autorize a instalação de atualizações nas configurações do Android.");}return;}
  apkPending=false;Intent install=new Intent(Intent.ACTION_VIEW);install.setDataAndType(Uri.parse("content://"+getPackageName()+".atualizacao/update.apk"),"application/vnd.android.package-archive");install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivity(install);}catch(Exception e){message("Não foi possível abrir o instalador do Android.");}
 }
 private void deliverCallAnswer(){if(web==null||!allowed(web.getUrl()))return;web.evaluateJavascript("(()=>{if(!window.fsjCurrentUser)return;const id=FSJAndroid.pendingAnswer();if(id)document.dispatchEvent(new CustomEvent('fsj:answer-call',{detail:{id}}));})()",null);}
 private void receiveCalls(){
  if(exiting||DeviceStore.read(this).isEmpty())return;
  if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED){if(!callsPermissionAsked){callsPermissionAsked=true;requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},803);}return;}
  try{startForegroundService(new Intent(this,CallReceiverService.class));}catch(Exception e){message("Autorize notificações e mantenha o recebimento ativo para receber chamadas.");}
  if(android.os.Build.VERSION.SDK_INT>=34&&!((android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE)).canUseFullScreenIntent()&&!getSharedPreferences("device-calls-settings",0).getBoolean("fullScreenAsked",false)){
   getSharedPreferences("device-calls-settings",0).edit().putBoolean("fullScreenAsked",true).apply();new AlertDialog.Builder(this).setTitle("Chamadas na tela bloqueada").setMessage("Permita ao Reserva mostrar chamadas recebidas em tela cheia nas configurações do Android.").setPositiveButton("Configurar",(d,w)->{try{startActivity(new Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT",Uri.parse("package:"+getPackageName())));}catch(Exception ignored){}}).setNegativeButton("Depois",null).show();
  }
 }
 private org.json.JSONObject postDevice(String action,org.json.JSONObject data,String cookie,String device,java.util.concurrent.atomic.AtomicReference<String> receivedCookie)throws Exception{
  HttpURLConnection c=(HttpURLConnection)new URL(ROOT+"api/device-calls/"+action).openConnection();try{c.setConnectTimeout(8000);c.setReadTimeout(8000);c.setInstanceFollowRedirects(false);c.setRequestMethod("POST");c.setRequestProperty("X-FSJ-Request","1");c.setRequestProperty("Content-Type","application/json");if(cookie!=null&&!cookie.isEmpty())c.setRequestProperty("Cookie",cookie);if(device!=null&&!device.isEmpty())c.setRequestProperty("Authorization","Bearer "+device);c.setDoOutput(true);try(OutputStream out=c.getOutputStream()){out.write(data.toString().getBytes("UTF-8"));}int code=c.getResponseCode();if(code!=200)throw new IOException(code==401||code==403?"Vínculo expirado. Entre novamente com login e senha.":"Chamada indisponível ou servidor sem conexão.");if(receivedCookie!=null)receivedCookie.set(c.getHeaderField("Set-Cookie"));ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))!=-1){bytes.write(buffer,0,n);if(bytes.size()>200000)throw new IOException("Resposta inválida");}}return new org.json.JSONObject(bytes.toString("UTF-8"));}finally{c.disconnect();}
 }
 private void bindDevice(){
  if(exiting||web==null||!allowed(web.getUrl()))return;
  if(answerSession){receiveCalls();deliverCallAnswer();return;}
  String cookie=CookieManager.getInstance().getCookie(ROOT);if(cookie==null||!cookie.contains("fsj_session="))return;
  if(cookie.equals(lastBoundCookie)&&!DeviceStore.read(this).isEmpty()){receiveCalls();return;}
  if(!binding.compareAndSet(false,true))return;
  new Thread(()->{try{org.json.JSONObject data=new org.json.JSONObject().put("previous",DeviceStore.read(this));String token=postDevice("bind",data,cookie,null,null).getString("token");DeviceStore.save(this,token);lastBoundCookie=cookie;runOnUiThread(()->receiveCalls());}catch(Exception e){message(e.getMessage());}finally{binding.set(false);}},"fsj-bind-device").start();
 }
 private void answerCall(){
  final String id=pendingCallAnswer,device=DeviceStore.read(this);if(id==null||id.isEmpty())return;if(device.isEmpty()){pendingCallAnswer="";message("Entre uma vez com login e senha para vincular este aparelho.");open();return;}
  if(!answering.compareAndSet(false,true))return;currentAnswerRoom=id;answerSession=true;android.app.NotificationManager nm=(android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.cancel(12);IncomingCallActivity.dismiss();
  new Thread(()->{try{String prior=CookieManager.getInstance().getCookie(ROOT);if(prior!=null)postDevice("logout",new org.json.JSONObject(),prior,null,null);java.util.concurrent.atomic.AtomicReference<String> result=new java.util.concurrent.atomic.AtomicReference<>();postDevice("answer",new org.json.JSONObject().put("room",id),null,device,result);String cookie=result.get();if(cookie==null||!cookie.startsWith("fsj_session="))throw new IOException("Sessão de chamada inválida.");runOnUiThread(()->{if(exiting||web==null)return;if(android.os.Build.VERSION.SDK_INT>=27){setShowWhenLocked(true);setTurnScreenOn(true);}CookieManager.getInstance().setCookie(ROOT,cookie,value->{CookieManager.getInstance().flush();web.loadUrl(ROOT+"call.html");});});}catch(Exception e){pendingCallAnswer="";answerSession=false;message(e.getMessage());runOnUiThread(()->open());}finally{answering.set(false);}},"fsj-answer-call").start();
 }
 private boolean loginOrigin(){return !exiting&&!answerSession&&web!=null&&allowed(web.getUrl())&&"/".equals(Uri.parse(web.getUrl()).getPath());}
 public final class ExitBridge {
  @JavascriptInterface public String savedLogin(){java.util.concurrent.atomic.AtomicReference<String> result=new java.util.concurrent.atomic.AtomicReference<>("{}");java.util.concurrent.CountDownLatch done=new java.util.concurrent.CountDownLatch(1);runOnUiThread(()->{try{if(loginOrigin())result.set(DeviceStore.readLogin(MainActivity.this));}finally{done.countDown();}});try{done.await(2,java.util.concurrent.TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}return result.get();}
  @JavascriptInterface public void saveLogin(String name,String password,boolean remember){runOnUiThread(()->{if(!loginOrigin())return;if(!remember){DeviceStore.clearLogin(MainActivity.this);return;}if(name==null||password==null||name.length()>100||password.length()<10||password.length()>200)return;try{DeviceStore.saveLogin(MainActivity.this,new org.json.JSONObject().put("name",name).put("password",password).toString());}catch(Exception e){message("Nao foi possivel salvar a senha neste aparelho.");}});}

  @JavascriptInterface public void sessionReady(){runOnUiThread(()->bindDevice());}
  @JavascriptInterface public synchronized String pendingAnswer(){String answer=pendingCallAnswer;pendingCallAnswer="";return answer==null?"":answer;}
  @JavascriptInterface public boolean nativeCallRinging(){return CallReceiverService.running;}
  @JavascriptInterface public void callEnded(){runOnUiThread(()->{if(web!=null&&allowed(web.getUrl()))closeSession(true);});}
  @JavascriptInterface public void exit(){runOnUiThread(()->{if(web!=null&&allowed(web.getUrl()))closeSession(false);});}
 }
 private void closeApplication(){closeSession(false);}
 private void closeSession(boolean keepDevice){
  if(exiting)return;exiting=true;final String finishedRoom=currentAnswerRoom;final String device=DeviceStore.read(this);if(keepDevice&&!finishedRoom.isEmpty())startService(new Intent(this,CallReceiverService.class).setAction("ignore").putExtra("room",finishedRoom));if(!keepDevice){stopService(new Intent(this,CallReceiverService.class));DeviceStore.clear(this);}
  final String cookie=CookieManager.getInstance().getCookie(ROOT);
  if(mediaRequest!=null){mediaRequest.deny();mediaRequest=null;}
  if(fileCallback!=null){fileCallback.onReceiveValue(null);fileCallback=null;}
  pendingDownload=null;if(activeDownload!=null)activeDownload.disconnect();
  if(web!=null){web.stopLoading();web.onPause();web.removeJavascriptInterface("FSJAndroid");layout.removeView(web);web.destroy();web=null;}
  WebStorage.getInstance().deleteAllData();
  CookieManager.getInstance().removeAllCookies(value->CookieManager.getInstance().flush());
  new Thread(()->{HttpURLConnection c=null;try{if(keepDevice&&!finishedRoom.isEmpty()&&!device.isEmpty())postDevice("dismiss",new org.json.JSONObject().put("room",finishedRoom),null,device,null);if(!keepDevice&&!device.isEmpty())postDevice("unbind",new org.json.JSONObject(),null,device,null);c=(HttpURLConnection)new URL(ROOT+"api/device-calls/logout").openConnection();c.setConnectTimeout(2500);c.setReadTimeout(2500);c.setInstanceFollowRedirects(false);c.setRequestMethod("POST");c.setRequestProperty("X-FSJ-Request","1");c.setRequestProperty("Content-Type","application/json");if(cookie!=null)c.setRequestProperty("Cookie",cookie);c.setDoOutput(true);try(OutputStream out=c.getOutputStream()){out.write("{}".getBytes(java.nio.charset.StandardCharsets.UTF_8));}c.getResponseCode();}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}},"fsj-logout").start();
  Intent home=new Intent(Intent.ACTION_MAIN);home.addCategory(Intent.CATEGORY_HOME);home.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);try{startActivity(home);}catch(Exception ignored){}finishAndRemoveTask();
 }
 private void open(){CookieManager.getInstance().flush();sslNotice=false;web.setVisibility(View.VISIBLE);web.onResume();web.loadUrl(ROOT);}
 private void requestMedia(PermissionRequest request){
  if(exiting||!allowed(request.getOrigin().toString())||isFinishing()){request.deny();return;}
  for(String resource:request.getResources())if(!PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)&&!PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)){request.deny();return;}
  if(mediaRequest!=null)mediaRequest.deny();mediaRequest=request;
  java.util.ArrayList<String> missing=new java.util.ArrayList<>();
  for(String resource:request.getResources()){String permission=PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)?android.Manifest.permission.CAMERA:android.Manifest.permission.RECORD_AUDIO;if(checkSelfPermission(permission)!=android.content.pm.PackageManager.PERMISSION_GRANTED)missing.add(permission);}
  if(missing.isEmpty())grantMedia();else requestPermissions(missing.toArray(new String[0]),802);
 }
 private void grantMedia(){PermissionRequest request=mediaRequest;mediaRequest=null;if(request==null)return;if(isFinishing()||!allowed(request.getOrigin().toString())){request.deny();return;}for(String resource:request.getResources()){String permission=PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)?android.Manifest.permission.CAMERA:android.Manifest.permission.RECORD_AUDIO;if(checkSelfPermission(permission)!=android.content.pm.PackageManager.PERMISSION_GRANTED){request.deny();return;}}request.grant(request.getResources());}
 @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);if(request==802)grantMedia();if(request==803){if(android.os.Build.VERSION.SDK_INT<33||checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==android.content.pm.PackageManager.PERMISSION_GRANTED)receiveCalls();else message("Notificações não autorizadas. O toque em segundo plano ficará indisponível; as chamadas continuam visíveis com o Reserva aberto.");}}
 private void message(String text){runOnUiThread(()->{if(!isFinishing())new AlertDialog.Builder(this).setMessage(text).setPositiveButton("OK",null).show();});}
 @Override protected void onResume(){super.onResume();if(web!=null)web.onResume();if(apkPending&&getPackageManager().canRequestPackageInstalls())installUpdate();else checkUpdate();updateHandler.removeCallbacks(updateTicker);updateHandler.postDelayed(updateTicker,60000);}
 @Override protected void onPause(){updateHandler.removeCallbacks(updateTicker);if(web!=null){CookieManager.getInstance().flush();web.onPause();}super.onPause();}
 @Override public void onBackPressed(){if(fullscreenView!=null){hideFullscreen();return;}if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==700&&fileCallback!=null){Uri[] uris=null;if(result==RESULT_OK&&data!=null&&data.getData()!=null)uris=new Uri[]{data.getData()};fileCallback.onReceiveValue(uris);fileCallback=null;}if(request==701&&result==RESULT_OK&&data!=null&&data.getData()!=null&&pendingDownload!=null){final String url=pendingDownload;final Uri destination=data.getData();pendingDownload=null;final String cookie=CookieManager.getInstance().getCookie(url);new Thread(()->{HttpURLConnection c=null;try{if(!allowed(url))throw new IOException("Destino bloqueado");c=(HttpURLConnection)new URL(url).openConnection();activeDownload=c;c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(30000);if(cookie!=null)c.setRequestProperty("Cookie",cookie);if(c.getResponseCode()!=200)throw new IOException("Download não autorizado ou indisponível");try(InputStream in=c.getInputStream();OutputStream out=getContentResolver().openOutputStream(destination)){if(out==null)throw new IOException("Destino indisponível");byte[] b=new byte[65536];int n;while(!exiting&&(n=in.read(b))!=-1)out.write(b,0,n);}message("Vídeo salvo.");}catch(Exception e){message("Não foi possível salvar: "+e.getMessage());}finally{if(c!=null)c.disconnect();activeDownload=null;}},"fsj-vm-download").start();}}
 @Override protected void onDestroy(){updateHandler.removeCallbacks(updateTicker);if(mediaRequest!=null){mediaRequest.deny();mediaRequest=null;}if(fileCallback!=null)fileCallback.onReceiveValue(null);if(web!=null){web.removeJavascriptInterface("FSJAndroid");web.stopLoading();web.destroy();}super.onDestroy();}
}
