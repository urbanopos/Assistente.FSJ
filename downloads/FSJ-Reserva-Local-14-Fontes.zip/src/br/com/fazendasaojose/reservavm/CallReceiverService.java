package br.com.fazendasaojose.reservavm;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;

/** Recebe apenas convites da sessão autenticada. Não captura áudio ou vídeo. */
public final class CallReceiverService extends Service {
 static final String ROOT="https://192.168.1.114:8443/", STATUS="fsj_recebimento", CALL="fsj_toque_chamadas_v1";
 static volatile boolean running=false;
 private volatile boolean stopping=false;private volatile HttpURLConnection connection;
 private String active="";private boolean disconnected=false,statusReady=false;
 private final Set<String> ignored=Collections.synchronizedSet(new HashSet<String>());
 private NotificationManager manager;private Thread worker;
 private PendingIntent open(String call){Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);if(call!=null)i.putExtra("fsj_answer",call);return PendingIntent.getActivity(this,call==null?1:call.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 private PendingIntent command(String action,String id){Intent i=new Intent(this,CallReceiverService.class);i.setAction(action);if(id!=null)i.putExtra("room",id);return PendingIntent.getService(this,action.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 private Notification status(String text){return new Notification.Builder(this,STATUS).setSmallIcon(android.R.drawable.sym_action_call).setContentTitle("FSJ Reserva · recebimento de chamadas").setContentText(text).setContentIntent(open(null)).setOngoing(true).addAction(new Notification.Action.Builder(null,"Pausar recebimento",command("pause",null)).build()).build();}
 @Override public void onCreate(){super.onCreate();manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);NotificationChannel status=new NotificationChannel(STATUS,"Recebimento ativo",NotificationManager.IMPORTANCE_LOW);status.setDescription("Mantém a conexão de convites enquanto o Reserva está minimizado.");manager.createNotificationChannel(status);NotificationChannel calls=new NotificationChannel(CALL,"Toque de chamadas FSJ",NotificationManager.IMPORTANCE_HIGH);calls.setDescription("Toque exclusivo para chamadas de voz e vídeo recebidas no FSJ.");calls.setSound(Uri.parse("android.resource://"+getPackageName()+"/raw/fsj_toque"),new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());calls.enableVibration(true);calls.setVibrationPattern(new long[]{0,350,180,350,1200});manager.createNotificationChannel(calls);}
 @Override public int onStartCommand(Intent i,int flags,int id){
  if(i==null)i=new Intent();
  if("pause".equals(i.getAction())){getSharedPreferences("fsj-calls",MODE_PRIVATE).edit().putBoolean("paused",true).apply();stopSelf();return START_NOT_STICKY;}
  if("ignore".equals(i.getAction())){String room=i.getStringExtra("room");ignored.add(room);manager.cancel(12);IncomingCallActivity.dismiss();active="";dismissRemote(room);return START_NOT_STICKY;}
  if(DeviceStore.read(this).isEmpty()){stopSelf();return START_NOT_STICKY;}
  if(android.os.Build.VERSION.SDK_INT>=34)startForeground(11,status("Conectando ao servidor da fazenda…"),ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);else startForeground(11,status("Conectando ao servidor da fazenda…"));
  if(worker==null||!worker.isAlive()){running=true;worker=new Thread(()->loop(),"fsj-incoming-calls");worker.start();}return START_STICKY;
 }
 private void dismissRemote(String room){new Thread(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(ROOT+"api/device-calls/dismiss").openConnection();c.setConnectTimeout(5000);c.setReadTimeout(5000);c.setRequestMethod("POST");c.setRequestProperty("X-FSJ-Request","1");c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Accept","application/json");c.setRequestProperty("Authorization","Bearer "+DeviceStore.read(this));c.setDoOutput(true);try(OutputStream out=c.getOutputStream()){out.write(new JSONObject().put("room",room).toString().getBytes("UTF-8"));}c.getResponseCode();}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}},"fsj-dismiss-call").start();}
 private void alert(JSONObject call)throws Exception{String id=call.getString("id");if(id.equals(active))return;active=id;String caller="Proprietário";JSONArray members=call.getJSONArray("members");for(int n=0;n<members.length();n++){JSONObject m=members.getJSONObject(n);if(m.getString("id").equals(call.getString("owner")))caller=m.getString("name");}
  Intent screen=new Intent(this,IncomingCallActivity.class).putExtra("room",id).putExtra("caller",caller);screen.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);PendingIntent full=PendingIntent.getActivity(this,id.hashCode()+991,screen,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder builder=new Notification.Builder(this,CALL).setSmallIcon(android.R.drawable.sym_action_call).setContentTitle(("audio".equals(call.optString("mode"))?"Chamada de voz":"Videochamada")+" · FSJ Reserva").setContentText(caller+" está chamando").setCategory(Notification.CATEGORY_CALL).setVisibility(Notification.VISIBILITY_PRIVATE).setContentIntent(open(id)).setAutoCancel(true).setTimeoutAfter(45000).addAction(new Notification.Action.Builder(null,"Atender",open(id)).build()).addAction(new Notification.Action.Builder(null,"Agora não",command("ignore",id)).build());if(Build.VERSION.SDK_INT<34||manager.canUseFullScreenIntent())builder.setFullScreenIntent(full,true);Notification notification=builder.build();notification.flags|=Notification.FLAG_INSISTENT;manager.notify(12,notification);
 }
 private void loop(){while(!stopping){HttpURLConnection c=null;try{
   c=(HttpURLConnection)new URL(ROOT+"api/device-calls/poll").openConnection();connection=c;c.setInstanceFollowRedirects(false);c.setConnectTimeout(6000);c.setReadTimeout(6000);c.setRequestMethod("POST");c.setRequestProperty("X-FSJ-Request","1");c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Accept","application/json");c.setRequestProperty("Authorization","Bearer "+DeviceStore.read(this));c.setDoOutput(true);try(OutputStream out=c.getOutputStream()){out.write("{}".getBytes("UTF-8"));}int status=c.getResponseCode();
   if(status==401||status==403){DeviceStore.clear(this);manager.cancel(12);active="";manager.notify(11,status("Sessão expirada. Abra o Reserva e entre novamente."));break;}
   if(status!=200)throw new IOException("Servidor indisponível");ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] buffer=new byte[4096];int size;while((size=in.read(buffer))!=-1){bytes.write(buffer,0,size);if(bytes.size()>1000000)throw new IOException("Resposta inválida");}}
   JSONObject data=new JSONObject(bytes.toString("UTF-8"));String self=data.getString("self_id");JSONArray calls=data.getJSONArray("calls");JSONObject incoming=null;
   for(int n=0;n<calls.length();n++){JSONObject call=calls.getJSONObject(n);String id=call.getString("id"),owner=call.getString("owner");if(owner.equals(self)||ignored.contains(id))continue;JSONArray members=call.getJSONArray("members");boolean callerPresent=false,selfPresent=false;for(int m=0;m<members.length();m++){JSONObject member=members.getJSONObject(m);if(owner.equals(member.getString("id")))callerPresent=member.optBoolean("present");if(self.equals(member.getString("id")))selfPresent=member.optBoolean("present");}if(callerPresent&&!selfPresent){incoming=call;break;}}
   if(incoming!=null)alert(incoming);else{manager.cancel(12);active="";IncomingCallActivity.dismiss();}if(disconnected||!statusReady){manager.notify(11,status("Pronto para receber chamadas FSJ."));disconnected=false;statusReady=true;}
  }catch(Exception error){if(!stopping){manager.cancel(12);active="";if(!disconnected){manager.notify(11,status("Sem conexão. Tentando novamente…"));disconnected=true;}}}finally{connection=null;if(c!=null)c.disconnect();}
  try{Thread.sleep(disconnected?10000:2500);}catch(InterruptedException end){break;}
 }running=false;}
 @Override public void onDestroy(){stopping=true;running=false;if(connection!=null)connection.disconnect();if(worker!=null)worker.interrupt();manager.cancel(12);IncomingCallActivity.dismiss();stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}
