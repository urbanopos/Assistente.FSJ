import tempfile,threading,signal
from pathlib import Path
import server
with tempfile.TemporaryDirectory() as directory:
 server.DATA=Path(directory);server.init()
 for name,role in [('dono','owner'),('pessoa','viewer'),('segunda','viewer'),('fora','viewer')]:server.adduser(name,'teste-chamada-123',role)
 app=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
 signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(SystemExit()))
 print(app.server_port,flush=True)
 try:app.serve_forever()
 finally:app.server_close()
