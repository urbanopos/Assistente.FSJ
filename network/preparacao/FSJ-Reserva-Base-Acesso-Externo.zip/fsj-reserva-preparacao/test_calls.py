import unittest
from calls import CallHub,CallError
class Tests(unittest.TestCase):
 def setUp(self):
  self.users={i:{'id':i,'name':i,'display_name':i,'role':'owner' if i=='o' else 'viewer'} for i in 'oabcd'};self.h=CallHub(self.users.get);self.owner=self.users['o'];self.viewer=self.users['a']
 def create(self,ids=['a']):return self.h.post(self.owner,'create',{'title':'Teste','participants':ids})['call']['id']
 def test_invites_authorization_and_signaling(self):
  with self.assertRaises(CallError):self.h.post(self.viewer,'create',{'participants':['o']})
  rid=self.create(['a','b','c']);self.assertEqual(self.h.list(self.users['d'])['calls'],[])
  with self.assertRaises(CallError):self.h.post(self.users['d'],'join',{'room':rid})
  own=self.h.post(self.owner,'join',{'room':rid});other=self.h.post(self.viewer,'join',{'room':rid})
  with self.assertRaises(CallError):self.h.post(self.viewer,'signal',{'room':rid,'nonce':'forged','to':'o','signal':{'type':'offer','sdp':'test'}})
  self.h.post(self.owner,'signal',{'room':rid,'nonce':own['nonce'],'to':'a','from':'spoof','signal':{'type':'offer','sdp':'test'}})
  result=self.h.post(self.viewer,'poll',{'room':rid,'nonce':other['nonce'],'after':0});self.assertEqual(result['events'][0]['from'],'o')
  self.assertEqual(self.h.post(self.users['b'],'join',{'room':rid})['call']['recording'],False)
  with self.assertRaises(CallError):self.h.post(self.viewer,'record',{'room':rid,'nonce':other['nonce'],'recording':True})
  self.h.post(self.owner,'record',{'room':rid,'nonce':own['nonce'],'recording':True});self.assertTrue(self.h.list(self.viewer)['calls'][0]['recording'])
  self.h.revoke('a')
  with self.assertRaises(CallError):self.h.post(self.viewer,'poll',{'room':rid,'nonce':other['nonce'],'after':0})
  self.h.post(self.owner,'end',{'room':rid});self.assertEqual(self.h.list(self.viewer)['calls'],[])
 def test_audio_mode_and_invalid_mode(self):
  call=self.h.post(self.owner,'create',{'title':'Voz','participants':['a'],'mode':'audio'})['call'];self.assertEqual(call['mode'],'audio')
  self.h.post(self.owner,'end',{'room':call['id']})
  with self.assertRaises(CallError):self.h.post(self.owner,'create',{'title':'Invalida','participants':['a'],'mode':'invalid'})
 def test_expiry_and_disconnected_owner(self):
  rid=self.create();self.h.post(self.owner,'join',{'room':rid});self.h.rooms[rid]['peers']['o']['seen']=0;self.assertEqual(self.h.list(self.viewer)['calls'],[])
 def test_maximum_and_invalid_candidate(self):
  with self.assertRaises(CallError):self.create(['a','b','c','d'])
  rid=self.create();one=self.h.post(self.owner,'join',{'room':rid});self.h.post(self.viewer,'join',{'room':rid})
  with self.assertRaises(CallError):self.h.post(self.owner,'signal',{'room':rid,'nonce':one['nonce'],'to':'a','signal':{'type':'candidate','candidate':{'candidate':'x','sdpMLineIndex':-1}}})
if __name__=='__main__':unittest.main()
