import unittest,tempfile,json,time,importlib.util,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import server
class MirrorTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();server.DATA=Path(self.temp.name);server.init();self.user=server.adduser('pessoa','senha-teste-123','viewer')
  with server.db() as c:self.uid=c.execute("select id from users where name='pessoa'").fetchone()[0]
  self.snap={'format':1,'people':[{'id':'p1','nome':'Pessoa A','ativo':True},{'id':'p2','nome':'Pessoa B','ativo':True}],'tasks':[{'id':'t1','descricao':'Atividade A','situacao':'Em aberto','prioridade':'urgente'},{'id':'t2','descricao':'Atividade B','situacao':'Em aberto'}],'task_people':[{'tarefa_id':'t1','pessoa_id':'p1'},{'tarefa_id':'t2','pessoa_id':'p2'}],'answers':[],'executions':[],'groups':[],'group_people':[]}
  self.save()
 def save(self):
  with server.db() as c:c.execute('insert or replace into mirror_state values(1,?,?,?)',(json.dumps(self.snap),time.time(),''))
 def tearDown(self):self.temp.cleanup()
 def test_scope_and_explicit_mapping(self):
  user={'id':self.uid,'role':'viewer'};self.assertEqual(server.mirror_view(user)['tasks'],[])
  with server.db() as c:c.execute('insert into mirror_links values(?,?)',(self.uid,'p1'))
  view=server.mirror_view(user);self.assertEqual([t['id'] for t in view['tasks']],['t1']);self.assertEqual([p['id'] for p in view['people']],['p1']);self.assertEqual(view['directory'],[])
  owner=server.mirror_view({'id':'owner','role':'owner'});self.assertEqual(len(owner['tasks']),2);self.assertEqual(len(owner['people']),2)
 def test_inactive_person_loses_access(self):
  with server.db() as c:c.execute('insert into mirror_links values(?,?)',(self.uid,'p1'))
  self.assertIsNotNone(server.call_account(self.uid));self.snap['people'][0]['ativo']=False;self.save();self.assertIsNone(server.call_account(self.uid))
 def test_primary_invites_without_local_account_and_private_acceptance(self):
  server.adduser('dono','senha-teste-123','owner')
  with server.db() as c:owner=dict(c.execute("SELECT * FROM users WHERE name='dono'").fetchone());viewer=dict(c.execute('SELECT * FROM users WHERE id=?',(self.uid,)).fetchone())
  hub=server.CallHub(server.call_account);call=hub.post(owner,'create',{'title':'Conversa','participants':['p:p1','p:p2']})['call']
  self.assertEqual({m['id'] for m in call['members']},{owner['id'],'p:p1','p:p2'})
  self.assertEqual(hub.list(server.call_identity(viewer))['calls'],[])
  with self.assertRaises(server.CallError):hub.post(server.call_identity(viewer),'join',{'room':call['id']})
  with server.db() as c:c.execute('INSERT INTO mirror_links VALUES(?,?)',(self.uid,'p1'))
  identity=server.call_identity(viewer);self.assertEqual(identity['id'],'p:p1');self.assertEqual(len(hub.list(identity)['calls']),1)
  hub.post(identity,'join',{'room':call['id']})
  with server.db() as c:c.execute("UPDATE users SET status='blocked' WHERE id=?",(self.uid,))
  self.assertIsNone(server.call_account('p:p1'));self.assertIsNotNone(server.call_account('p:p2'))
 def test_bad_connection_preserves_local_records(self):
  (server.DATA/'sync.json').write_text('{"url":"https://invalid/","key":"bad"}');server.mirror_sync_once();snap,meta=server.mirror_snapshot();self.assertEqual(snap['tasks'],self.snap['tasks']);self.assertTrue(meta['error'])
if __name__=='__main__':unittest.main()
