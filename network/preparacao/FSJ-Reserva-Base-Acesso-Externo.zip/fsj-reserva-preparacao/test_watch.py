import unittest
from unittest.mock import patch
from calls import WatchHub,CallError
class WatchTests(unittest.TestCase):
 def setUp(self):
  self.accounts={k:{'id':k,'name':k,'display_name':k,'role':'owner' if k=='owner' else 'viewer'} for k in ['owner','p:one','p:two','outside']}
  self.hub=WatchHub(self.accounts.get);self.owner=self.accounts['owner'];self.viewer=self.accounts['p:one'];self.outside=self.accounts['outside']
 def create(self):return self.hub.post(self.owner,'create',{'participants':['p:one']},{'id':'video','title':'Treino'})['session']['id']
 def test_invitation_stream_grant_and_end(self):
  ident=self.create();self.assertTrue(self.hub.allowed(self.viewer,'video'));self.assertFalse(self.hub.allowed(self.outside,'video'))
  with self.assertRaises(CallError):self.hub.post(self.outside,'join',{'session':ident})
  with self.assertRaises(CallError):self.hub.post(self.viewer,'control',{'session':ident,'position':3,'playing':True})
  joined=self.hub.post(self.viewer,'join',{'session':ident})['session'];self.assertTrue(next(m for m in joined['members'] if m['id']=='p:one')['joined'])
  self.hub.post(self.owner,'finish',{'session':ident});self.assertFalse(self.hub.allowed(self.viewer,'video'));self.assertEqual(self.hub.list(self.viewer)['sessions'],[])
 def test_clock_pause_seek_and_expiration(self):
  with patch('calls.time.monotonic',return_value=100):ident=self.create();self.hub.post(self.owner,'control',{'session':ident,'position':2,'playing':True})
  with patch('calls.time.monotonic',return_value=104):self.assertEqual(self.hub.list(self.viewer)['sessions'][0]['position'],6);self.hub.post(self.owner,'control',{'session':ident,'position':9,'playing':False})
  with patch('calls.time.monotonic',return_value=110):self.assertEqual(self.hub.list(self.viewer)['sessions'][0]['position'],9)
  with patch('calls.time.monotonic',return_value=151):self.assertEqual(self.hub.list(self.viewer)['sessions'],[])
 def test_blocked_account_loses_stream_grant(self):
  self.create();self.accounts.pop('p:one');self.assertFalse(self.hub.allowed(self.viewer,'video'))
if __name__=='__main__':unittest.main()
