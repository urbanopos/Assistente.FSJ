import tempfile,unittest,json,time,hmac,hashlib,base64
from pathlib import Path
import server
class RTCTests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.old=server.DATA;server.DATA=Path(self.tmp.name);self.user={'id':'approved','role':'viewer'}
 def tearDown(self):server.DATA=self.old;self.tmp.cleanup()
 def test_no_configuration_keeps_local_mode(self):self.assertEqual(server.rtc_config(self.user),{'iceServers':[],'configured':False})
 def test_ephemeral_credentials_without_master_secret(self):
  secret='a'*64;(server.DATA/'rede.json').write_text(json.dumps({'turn_host':'turn.example.com','turn_secret':secret}))
  result=server.rtc_config(self.user);self.assertTrue(result['configured']);relay=result['iceServers'][1];expiry,uid=relay['username'].split(':');self.assertEqual(uid,'approved');self.assertTrue(time.time()+7100<int(expiry)<time.time()+7300);self.assertEqual(relay['credential'],base64.b64encode(hmac.new(secret.encode(),relay['username'].encode(),hashlib.sha1).digest()).decode());self.assertNotIn(secret,json.dumps(result));self.assertEqual((server.DATA/'rede.json').stat().st_mode&0o777,0o600)
 def test_fixed_public_ip_requires_no_dns_service(self):
  (server.DATA/'rede.json').write_text(json.dumps({'turn_host':'8.8.4.4','turn_secret':'a'*64}));self.assertTrue(server.rtc_config(self.user)['configured'])
 def test_forwarded_ip_only_from_configured_loopback(self):
  h=object.__new__(server.Handler);h.client_address=('127.0.0.1',1234);h.headers={'X-Forwarded-For':'1.2.3.4'};self.assertEqual(h.client_ip(),'127.0.0.1')
  (server.DATA/'proxy.json').write_text('{"trusted_loopback":true}');self.assertEqual(h.client_ip(),'1.2.3.4');h.client_address=('192.168.1.8',1234);self.assertEqual(h.client_ip(),'192.168.1.8');h.client_address=('127.0.0.1',1234);h.headers={'X-Forwarded-For':'1.2.3.4, 9.9.9.9'};self.assertEqual(h.client_ip(),'127.0.0.1')
 def test_invalid_host_fails_closed(self):
  (server.DATA/'rede.json').write_text(json.dumps({'turn_host':'host.example.com/path','turn_secret':'a'*64}));result=server.rtc_config(self.user);self.assertFalse(result['configured']);self.assertEqual(result['iceServers'],[])
if __name__=='__main__':unittest.main()
