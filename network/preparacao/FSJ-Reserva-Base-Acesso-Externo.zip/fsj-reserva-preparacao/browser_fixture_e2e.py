import sys,tempfile,json,signal,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent));import server
with tempfile.TemporaryDirectory() as d:
 server.DATA=Path(d);server.init()
 for name,role in [('dono','owner'),('pessoa','viewer'),('segunda','viewer'),('fora','viewer')]:server.adduser(name,'teste-chamada-123',role)
 snap={'format':1,'people':[{'id':'p1','nome':'Pessoa principal','ativo':True},{'id':'p2','nome':'Outra pessoa','ativo':True}],'tasks':[],'task_people':[],'groups':[],'group_people':[],'answers':[],'executions':[]}
 with server.db() as c:
  c.execute('INSERT INTO mirror_state VALUES(1,?,?,?)',(json.dumps(snap),time.time(),''))
  for name,pid in [('pessoa','p1'),('segunda','p2')]:uid=c.execute('SELECT id FROM users WHERE name=?',(name,)).fetchone()['id'];c.execute('INSERT INTO mirror_links VALUES(?,?)',(uid,pid))
  import subprocess
  sample=Path(d)/'sample.webm';subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-f','lavfi','-i','color=c=blue:s=160x90:d=16','-c:v','libvpx-vp9','-y',str(sample)],check=True);raw=sample.read_bytes()
  for ident,title,inst,allowed in [('a'*32,'Institucional',1,'*'),('b'*32,'Treinamento',0,''),('c'*32,' Treinamento ',0,'')]:
   (server.DATA/'videos'/ident).write_bytes(raw);c.execute('INSERT INTO videos VALUES(?,?,?,?,?,?,?)',(ident,title,'video/webm',len(raw),inst,allowed,time.time()))
 app=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler);print(app.server_port,flush=True)
 signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(SystemExit()))
 try:app.serve_forever()
 finally:app.server_close()
